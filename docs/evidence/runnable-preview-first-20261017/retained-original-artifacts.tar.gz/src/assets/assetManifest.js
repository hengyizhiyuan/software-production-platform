/**
 * src/assets/assetManifest.js
 *
 * Original-style asset manifest for the Plants vs. Zombies web game.
 *
 * Every asset in this project is *original, procedurally described artwork*.
 * No third-party or retail-game bitmaps are referenced or bundled. Each entry
 * below tells the renderer how to draw a sprite from primitives (rectangles,
 * ellipses, circles and polygons) using a small shared palette, so the manifest
 * stays self-contained and dependency free.
 *
 * Coordinate conventions:
 *   - Sizes and coordinates are logical pixels of the 900x600 play field.
 *   - `anchor` is the normalised origin used when placing the sprite
 *     (0,0 = top-left, 0.5,1 = bottom-centre for ground-standing sprites).
 *   - `layers` are drawn in array order (first drawn is furthest back).
 *   - Shape `fill` values are palette tokens resolved via `resolveColor`.
 */
(function (root, factory) {
  'use strict';
  var manifest = factory();
  if (typeof module === 'object' && module && module.exports) {
    module.exports = manifest;
  } else {
    root.PVZAssetManifest = manifest;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var VERSION = '1.0.0';

  /**
   * Shared original-art palette. Values are plain CSS colour strings.
   */
  var PALETTE = Object.freeze({
    lawnLight: '#8ec44a',
    lawnDark: '#77b23c',
    skyDay: '#bfe6ff',
    houseWall: '#d9c7a0',
    houseWallDark: '#b8a279',
    sunCore: '#fff4b0',
    sunEdge: '#ffcf3a',
    sunGlow: '#ffe27a',
    stemGreen: '#3f9a2f',
    leafGreen: '#54b544',
    leafDark: '#368a2a',
    leafDeep: '#205a18',
    peaGreen: '#6ec24a',
    peaHi: '#a8e07a',
    wallNut: '#c98a3c',
    wallNutDark: '#a76d2b',
    wallNutLight: '#e0b25f',
    petalWhite: '#fdf6d8',
    petalShadow: '#e8dca6',
    flowerCenter: '#f2b632',
    zombieSkin: '#b9c7a8',
    zombieSkinDark: '#93a684',
    zombieShirt: '#6f7f8c',
    zombieShirtDark: '#596773',
    zombiePants: '#4a4f57',
    hairDark: '#3b4250',
    coneOrange: '#e08a2e',
    coneOrangeDark: '#b96c1c',
    shadow: 'rgba(0,0,0,0.18)',
    white: '#ffffff',
    black: '#1b1b1b'
  });

  /**
   * Resolve a palette token to a CSS colour. Unknown tokens (for example an
   * inline 'rgba(...)' string) are returned unchanged so shapes may also carry
   * literal colours.
   */
  function resolveColor(token) {
    if (typeof token !== 'string') {
      return token;
    }
    if (Object.prototype.hasOwnProperty.call(PALETTE, token)) {
      return PALETTE[token];
    }
    return token;
  }

  /**
   * Complete manifest of original assets keyed by stable logical id.
   */
  var ASSETS = Object.freeze({
    'background.lawn': {
      id: 'background.lawn',
      kind: 'background',
      size: { width: 900, height: 600 },
      anchor: { x: 0, y: 0 },
      grid: {
        rows: 5,
        cols: 9,
        originX: 110,
        originY: 84,
        cellWidth: 87.78,
        cellHeight: 103.2
      },
      layers: [
        { type: 'rect', x: 0, y: 0, width: 900, height: 84, fill: 'skyDay' },
        { type: 'rect', x: 0, y: 84, width: 110, height: 516, fill: 'houseWall' },
        { type: 'rect', x: 100, y: 84, width: 10, height: 516, fill: 'houseWallDark' },
        { type: 'rect', x: 110, y: 84, width: 790, height: 103.2, fill: 'lawnLight' },
        { type: 'rect', x: 110, y: 187.2, width: 790, height: 103.2, fill: 'lawnDark' },
        { type: 'rect', x: 110, y: 290.4, width: 790, height: 103.2, fill: 'lawnLight' },
        { type: 'rect', x: 110, y: 393.6, width: 790, height: 103.2, fill: 'lawnDark' },
        { type: 'rect', x: 110, y: 496.8, width: 790, height: 103.2, fill: 'lawnLight' }
      ]
    },

    'sun.token': {
      id: 'sun.token',
      kind: 'pickup',
      size: { width: 56, height: 56 },
      anchor: { x: 0.5, y: 0.5 },
      layers: [
        { type: 'circle', cx: 28, cy: 28, r: 26, fill: 'sunGlow' },
        { type: 'circle', cx: 28, cy: 28, r: 20, fill: 'sunEdge' },
        { type: 'circle', cx: 28, cy: 28, r: 13, fill: 'sunCore' }
      ]
    },

    'projectile.pea': {
      id: 'projectile.pea',
      kind: 'projectile',
      size: { width: 24, height: 24 },
      anchor: { x: 0.5, y: 0.5 },
      layers: [
        { type: 'circle', cx: 12, cy: 12, r: 10, fill: 'peaGreen' },
        { type: 'circle', cx: 9, cy: 9, r: 3.5, fill: 'peaHi' }
      ]
    },

    'plant.peashooter': {
      id: 'plant.peashooter',
      kind: 'plant',
      size: { width: 80, height: 100 },
      anchor: { x: 0.5, y: 1 },
      layers: [
        { type: 'ellipse', cx: 40, cy: 96, rx: 26, ry: 7, fill: 'shadow' },
        { type: 'rect', x: 36, y: 50, width: 8, height: 46, fill: 'stemGreen' },
        { type: 'polygon', points: [[36, 70], [8, 60], [4, 74], [34, 80]], fill: 'leafGreen' },
        { type: 'polygon', points: [[44, 74], [72, 64], [76, 78], [46, 82]], fill: 'leafDark' },
        { type: 'circle', cx: 38, cy: 44, r: 24, fill: 'stemGreen' },
        { type: 'circle', cx: 30, cy: 36, r: 9, fill: 'leafGreen' },
        { type: 'circle', cx: 58, cy: 42, r: 11, fill: 'leafDark' },
        { type: 'circle', cx: 62, cy: 42, r: 6, fill: 'leafDeep' },
        { type: 'circle', cx: 34, cy: 40, r: 6, fill: 'white' },
        { type: 'circle', cx: 36, cy: 41, r: 3, fill: 'black' }
      ]
    },

    'plant.sunflower': {
      id: 'plant.sunflower',
      kind: 'plant',
      size: { width: 80, height: 100 },
      anchor: { x: 0.5, y: 1 },
      layers: [
        { type: 'ellipse', cx: 40, cy: 96, rx: 26, ry: 7, fill: 'shadow' },
        { type: 'rect', x: 36, y: 52, width: 8, height: 44, fill: 'stemGreen' },
        { type: 'polygon', points: [[36, 72], [10, 64], [8, 78], [34, 82]], fill: 'leafGreen' },
        { type: 'polygon', points: [[44, 76], [72, 68], [74, 82], [46, 84]], fill: 'leafDark' },
        { type: 'circle', cx: 60, cy: 42, r: 11, fill: 'petalWhite' },
        { type: 'circle', cx: 54.1, cy: 55.9, r: 11, fill: 'petalWhite' },
        { type: 'circle', cx: 40, cy: 62, r: 11, fill: 'petalWhite' },
        { type: 'circle', cx: 25.9, cy: 55.9, r: 11, fill: 'petalWhite' },
        { type: 'circle', cx: 20, cy: 42, r: 11, fill: 'petalWhite' },
        { type: 'circle', cx: 25.9, cy: 28.1, r: 11, fill: 'petalWhite' },
        { type: 'circle', cx: 40, cy: 22, r: 11, fill: 'petalWhite' },
        { type: 'circle', cx: 54.1, cy: 28.1, r: 11, fill: 'petalWhite' },
        { type: 'circle', cx: 40, cy: 42, r: 14, fill: 'flowerCenter' },
        { type: 'circle', cx: 34, cy: 40, r: 5, fill: 'white' },
        { type: 'circle', cx: 36, cy: 41, r: 2.5, fill: 'black' },
        { type: 'circle', cx: 46, cy: 40, r: 5, fill: 'white' },
        { type: 'circle', cx: 48, cy: 41, r: 2.5, fill: 'black' }
      ]
    },

    'plant.wallnut': {
      id: 'plant.wallnut',
      kind: 'plant',
      size: { width: 72, height: 96 },
      anchor: { x: 0.5, y: 1 },
      layers: [
        { type: 'ellipse', cx: 36, cy: 92, rx: 24, ry: 7, fill: 'shadow' },
        { type: 'ellipse', cx: 36, cy: 50, rx: 28, ry: 42, fill: 'wallNut' },
        { type: 'ellipse', cx: 28, cy: 34, rx: 12, ry: 14, fill: 'wallNutLight' },
        { type: 'ellipse', cx: 44, cy: 70, rx: 16, ry: 16, fill: 'wallNutDark' },
        { type: 'circle', cx: 26, cy: 44, r: 6, fill: 'white' },
        { type: 'circle', cx: 28, cy: 45, r: 3, fill: 'black' },
        { type: 'circle', cx: 48, cy: 44, r: 6, fill: 'white' },
        { type: 'circle', cx: 50, cy: 45, r: 3, fill: 'black' },
        { type: 'polygon', points: [[30, 62], [42, 62], [36, 68]], fill: 'black' }
      ]
    },

    'zombie.basic': {
      id: 'zombie.basic',
      kind: 'zombie',
      size: { width: 72, height: 120 },
      anchor: { x: 0.5, y: 1 },
      layers: [
        { type: 'ellipse', cx: 36, cy: 116, rx: 28, ry: 8, fill: 'shadow' },
        { type: 'rect', x: 24, y: 86, width: 10, height: 30, fill: 'zombiePants' },
        { type: 'rect', x: 40, y: 86, width: 10, height: 30, fill: 'zombiePants' },
        { type: 'rect', x: 54, y: 50, width: 12, height: 44, fill: 'zombieSkinDark' },
        { type: 'rect', x: 20, y: 46, width: 34, height: 44, fill: 'zombieShirt' },
        { type: 'rect', x: 20, y: 74, width: 34, height: 16, fill: 'zombieShirtDark' },
        { type: 'rect', x: 6, y: 52, width: 12, height: 42, fill: 'zombieSkin' },
        { type: 'circle', cx: 37, cy: 32, r: 20, fill: 'zombieSkin' },
        { type: 'circle', cx: 45, cy: 38, r: 12, fill: 'zombieSkinDark' },
        { type: 'polygon', points: [[19, 20], [30, 10], [40, 14], [49, 8], [56, 18], [52, 24], [22, 26]], fill: 'hairDark' },
        { type: 'circle', cx: 30, cy: 30, r: 5, fill: 'white' },
        { type: 'circle', cx: 31, cy: 31, r: 2.5, fill: 'black' },
        { type: 'circle', cx: 46, cy: 30, r: 5, fill: 'white' },
        { type: 'circle', cx: 45, cy: 31, r: 2.5, fill: 'black' },
        { type: 'rect', x: 30, y: 42, width: 16, height: 5, fill: 'black' }
      ]
    },

    'zombie.conehead': {
      id: 'zombie.conehead',
      kind: 'zombie',
      extends: 'zombie.basic',
      size: { width: 72, height: 120 },
      anchor: { x: 0.5, y: 1 },
      layers: [
        { type: 'polygon', points: [[37, 2], [26, 26], [48, 26]], fill: 'coneOrange' },
        { type: 'polygon', points: [[37, 8], [31, 26], [43, 26]], fill: 'coneOrangeDark' }
      ]
    },

    'ui.sunCounter': {
      id: 'ui.sunCounter',
      kind: 'ui',
      size: { width: 140, height: 48 },
      anchor: { x: 0, y: 0 },
      layers: [
        { type: 'rect', x: 0, y: 0, width: 140, height: 48, fill: '#efe2b8' },
        { type: 'rect', x: 0, y: 0, width: 140, height: 4, fill: '#c9b784' },
        { type: 'circle', cx: 26, cy: 24, r: 16, fill: 'sunEdge' },
        { type: 'circle', cx: 26, cy: 24, r: 10, fill: 'sunCore' },
        { type: 'rect', x: 48, y: 12, width: 82, height: 24, fill: '#fdf6d8' }
      ]
    },

    'ui.seedCard': {
      id: 'ui.seedCard',
      kind: 'ui',
      size: { width: 64, height: 88 },
      anchor: { x: 0, y: 0 },
      layers: [
        { type: 'rect', x: 0, y: 0, width: 64, height: 88, fill: '#e6d4a0' },
        { type: 'rect', x: 3, y: 3, width: 58, height: 58, fill: '#f6ecc8' },
        { type: 'rect', x: 3, y: 63, width: 58, height: 22, fill: '#d9c58a' },
        { type: 'rect', x: 0, y: 84, width: 64, height: 4, fill: '#b9a26c' }
      ]
    },

    'card.peashooter': {
      id: 'card.peashooter',
      kind: 'ui',
      extends: 'ui.seedCard',
      size: { width: 64, height: 88 },
      anchor: { x: 0, y: 0 },
      layers: [
        { type: 'rect', x: 29, y: 44, width: 6, height: 16, fill: 'stemGreen' },
        { type: 'polygon', points: [[29, 52], [14, 46], [12, 56], [28, 58]], fill: 'leafGreen' },
        { type: 'circle', cx: 32, cy: 30, r: 15, fill: 'stemGreen' },
        { type: 'circle', cx: 47, cy: 30, r: 7, fill: 'leafDark' }
      ]
    },

    'card.sunflower': {
      id: 'card.sunflower',
      kind: 'ui',
      extends: 'ui.seedCard',
      size: { width: 64, height: 88 },
      anchor: { x: 0, y: 0 },
      layers: [
        { type: 'rect', x: 29, y: 44, width: 6, height: 16, fill: 'stemGreen' },
        { type: 'circle', cx: 45, cy: 30, r: 9, fill: 'petalWhite' },
        { type: 'circle', cx: 38.5, cy: 41.3, r: 9, fill: 'petalWhite' },
        { type: 'circle', cx: 25.5, cy: 41.3, r: 9, fill: 'petalWhite' },
        { type: 'circle', cx: 19, cy: 30, r: 9, fill: 'petalWhite' },
        { type: 'circle', cx: 25.5, cy: 18.7, r: 9, fill: 'petalWhite' },
        { type: 'circle', cx: 38.5, cy: 18.7, r: 9, fill: 'petalWhite' },
        { type: 'circle', cx: 32, cy: 30, r: 9, fill: 'flowerCenter' }
      ]
    },

    'card.wallnut': {
      id: 'card.wallnut',
      kind: 'ui',
      extends: 'ui.seedCard',
      size: { width: 64, height: 88 },
      anchor: { x: 0, y: 0 },
      layers: [
        { type: 'ellipse', cx: 32, cy: 36, rx: 18, ry: 22, fill: 'wallNut' },
        { type: 'ellipse', cx: 26, cy: 26, rx: 8, ry: 9, fill: 'wallNutLight' },
        { type: 'circle', cx: 26, cy: 36, r: 4, fill: 'white' },
        { type: 'circle', cx: 27, cy: 37, r: 2, fill: 'black' },
        { type: 'circle', cx: 38, cy: 36, r: 4, fill: 'white' },
        { type: 'circle', cx: 39, cy: 37, r: 2, fill: 'black' }
      ]
    }
  });

  var ASSET_IDS = Object.freeze(Object.keys(ASSETS));

  function getAsset(id) {
    return Object.prototype.hasOwnProperty.call(ASSETS, id) ? ASSETS[id] : null;
  }

  function getAssetsByKind(kind) {
    return ASSET_IDS
      .map(function (id) { return ASSETS[id]; })
      .filter(function (asset) { return asset.kind === kind; });
  }

  /**
   * Return an asset with any `extends` inheritance flattened. Parent layers are
   * drawn first; the child's own layers are appended on top.
   */
  function resolveAsset(id) {
    var asset = getAsset(id);
    if (!asset) {
      return null;
    }
    if (!asset.extends) {
      return asset;
    }
    var parent = resolveAsset(asset.extends);
    if (!parent) {
      return asset;
    }
    var merged = {};
    Object.keys(parent).forEach(function (key) { merged[key] = parent[key]; });
    Object.keys(asset).forEach(function (key) { merged[key] = asset[key]; });
    merged.layers = (parent.layers || []).concat(asset.layers || []);
    return merged;
  }

  return Object.freeze({
    version: VERSION,
    kind: 'procedural',
    palette: PALETTE,
    assets: ASSETS,
    ids: ASSET_IDS,
    resolveColor: resolveColor,
    getAsset: getAsset,
    getAssetsByKind: getAssetsByKind,
    resolveAsset: resolveAsset
  });
});
