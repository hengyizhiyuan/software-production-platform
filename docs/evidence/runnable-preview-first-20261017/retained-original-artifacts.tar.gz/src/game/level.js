/**
 * Plants vs. Zombies web game - "level" capability (first version).
 *
 * This module owns the single playable level of the first version: lawn
 * geometry, the zombie wave schedule and the level-level win/lose rules.
 * Nothing here imports another module, so it stays independent from the
 * plant, zombie, sun, state and renderer surfaces that are produced in
 * parallel; those modules are referenced only by plain string keys.
 *
 * Coordinate model (shared contract for the other modules):
 *   - the lawn is a grid of `rows` x `columns` cells;
 *   - a tile (row, column) covers x in [column, column + 1) and
 *     y in [row, row + 1) using continuous column/row units;
 *   - a zombie's x is a continuous column coordinate: it enters the lawn at
 *     ZOMBIE_SPAWN_X (just right of the last column) and walks left;
 *   - the house line is x === HOUSE_LINE_X, so a zombie whose x reaches
 *     HOUSE_LINE_X or below has entered the house - the level is lost;
 *   - the level is won when every scheduled zombie has spawned and no zombie
 *     is left standing.
 */

const LAWN_ROWS = 5;
const LAWN_COLS = 9;

/** Continuous column coordinate of the house line (left edge of the lawn). */
const HOUSE_LINE_X = 0;

/** Continuous column coordinate where zombies appear, just past the lawn. */
const ZOMBIE_SPAWN_X = LAWN_COLS + 0.5;

/** Sun the player starts the single level with. */
const STARTING_SUN = 50;

/**
 * Wave schedule of the one playable level (a first-night style level).
 * `startTime` is the absolute level time in seconds when the wave begins,
 * `interval` is the gap in seconds between the individual zombies of a wave,
 * `type` is a zombie key owned by src/game/zombies.js.
 */
const WAVE_DEFINITIONS = [
  { startTime: 18, type: 'basic', count: 1, interval: 0, final: false },
  { startTime: 42, type: 'basic', count: 2, interval: 6, final: false },
  { startTime: 72, type: 'basic', count: 3, interval: 5, final: false },
  { startTime: 104, type: 'basic', count: 4, interval: 4, final: true },
];

/** The single level admitted for the first version (no campaign surface). */
const LEVEL_DEFINITION = Object.freeze({
  id: 'level-1-1',
  name: 'Level 1-1',
  rows: LAWN_ROWS,
  columns: LAWN_COLS,
  startingSun: STARTING_SUN,
  houseLineX: HOUSE_LINE_X,
  zombieSpawnX: ZOMBIE_SPAWN_X,
  waves: Object.freeze(
    WAVE_DEFINITIONS.map((wave, index) => Object.freeze({ index, ...wave })),
  ),
});

/** Alias kept so consumers can name the definition whichever way reads best. */
const LEVEL = LEVEL_DEFINITION;
const LEVEL_CONFIG = LEVEL_DEFINITION;

/** Returns the wave list of a level definition. */
function getWaves(level = LEVEL_DEFINITION) {
  const definition = level || LEVEL_DEFINITION;
  return Array.isArray(definition.waves) ? definition.waves : [];
}

/** Returns one wave (0 based) or null when the index is out of range. */
function getWave(index, level = LEVEL_DEFINITION) {
  const waves = getWaves(level);
  return waves[index] || null;
}

/** Total number of zombies scheduled for the level. */
function getTotalZombieCount(level = LEVEL_DEFINITION) {
  return getWaves(level).reduce((total, wave) => total + (wave.count || 0), 0);
}

/** The last (flag) wave of the level, or null for an empty schedule. */
function getFinalWave(level = LEVEL_DEFINITION) {
  const waves = getWaves(level);
  return waves.length > 0 ? waves[waves.length - 1] : null;
}

/** Picks a lawn row for a zombie that is about to spawn. */
function pickSpawnRow(random = Math.random, level = LEVEL_DEFINITION) {
  const rows = (level || LEVEL_DEFINITION).rows || LAWN_ROWS;
  const rng = typeof random === 'function' ? random : Math.random;
  const value = Number(rng());
  const clamped = Number.isFinite(value)
    ? Math.min(Math.max(value, 0), 0.999999)
    : 0;
  return Math.floor(clamped * rows);
}

/** True when (row, column) addresses an existing lawn tile. */
function isInsideLawn(row, column) {
  return (
    Number.isInteger(row) &&
    Number.isInteger(column) &&
    row >= 0 &&
    row < LAWN_ROWS &&
    column >= 0 &&
    column < LAWN_COLS
  );
}

/** Continuous x of a tile centre, in column units. */
function columnCenter(column) {
  return column + 0.5;
}

/** Continuous y of a tile centre, in row units. */
function rowCenter(row) {
  return row + 0.5;
}

/** True when a zombie at this x has walked into the house (level lost). */
function hasReachedHouse(zombieX) {
  return Number.isFinite(zombieX) && zombieX <= HOUSE_LINE_X;
}

/** Fresh wave/spawn bookkeeping for a level run. */
function createLevelProgress(level = LEVEL_DEFINITION) {
  const definition = level || LEVEL_DEFINITION;
  return {
    levelId: definition.id,
    elapsed: 0,
    totalZombies: getTotalZombieCount(definition),
    spawnedZombies: 0,
    spawnedPerWave: getWaves(definition).map(() => 0),
  };
}

/** How many zombies are still waiting to appear. */
function getRemainingZombiesToSpawn(progress) {
  if (!progress) {
    return 0;
  }
  return Math.max((progress.totalZombies || 0) - (progress.spawnedZombies || 0), 0);
}

/** True once every scheduled zombie of the level has spawned. */
function hasAllWavesSpawned(progress) {
  if (!progress) {
    return false;
  }
  return (progress.spawnedZombies || 0) >= (progress.totalZombies || 0);
}

/**
 * Advances the wave clock by `deltaSeconds` and returns the zombies that are
 * due to spawn in that slice of time. Deterministic when `options.random` is
 * provided, which keeps the schedule testable.
 */
function advanceWaves(progress, deltaSeconds, options = {}) {
  const level = options.level || LEVEL_DEFINITION;
  const random = typeof options.random === 'function' ? options.random : Math.random;
  const current = progress || createLevelProgress(level);
  const waves = getWaves(level);
  const delta = Number.isFinite(deltaSeconds) && deltaSeconds > 0 ? deltaSeconds : 0;
  const previousElapsed = Number.isFinite(current.elapsed) ? current.elapsed : 0;
  const elapsed = previousElapsed + delta;

  const spawnedPerWave = waves.map((wave, index) => {
    const value = current.spawnedPerWave ? current.spawnedPerWave[index] : 0;
    return Number.isFinite(value) ? value : 0;
  });
  let spawnedZombies = Number.isFinite(current.spawnedZombies)
    ? current.spawnedZombies
    : 0;

  const spawns = [];
  waves.forEach((wave, waveIndex) => {
    const interval = Number.isFinite(wave.interval) ? wave.interval : 0;
    for (let index = spawnedPerWave[waveIndex]; index < (wave.count || 0); index += 1) {
      const spawnTime = wave.startTime + index * interval;
      if (spawnTime > elapsed) {
        break;
      }
      spawns.push({
        waveIndex,
        waveNumber: waveIndex + 1,
        type: wave.type,
        row: pickSpawnRow(random, level),
        time: spawnTime,
        final: Boolean(wave.final),
      });
      spawnedPerWave[waveIndex] = index + 1;
      spawnedZombies += 1;
    }
  });

  return {
    progress: {
      levelId: current.levelId || level.id,
      elapsed,
      totalZombies: Math.max(
        Number.isFinite(current.totalZombies) ? current.totalZombies : 0,
        getTotalZombieCount(level),
      ),
      spawnedZombies,
      spawnedPerWave,
    },
    spawns,
  };
}

/** Highest wave number that has already started (0 before the first wave). */
function getCurrentWaveNumber(progress) {
  if (!progress || !Array.isArray(progress.spawnedPerWave)) {
    return 0;
  }
  return progress.spawnedPerWave.reduce(
    (current, count, index) => (count > 0 ? index + 1 : current),
    0,
  );
}

/** True while the flag (last) wave is running or already finished. */
function isFinalWave(progress, level = LEVEL_DEFINITION) {
  const waves = getWaves(level);
  if (waves.length === 0) {
    return false;
  }
  return getCurrentWaveNumber(progress) === waves.length;
}

/** Win rule: every wave spawned and no zombie left on the lawn. */
function isLevelCleared(progress, remainingZombies) {
  return hasAllWavesSpawned(progress) && (Number(remainingZombies) || 0) <= 0;
}

/** Level state for a single frame: 'playing' or 'won'. */
function getLevelStatus(progress, remainingZombies) {
  return isLevelCleared(progress, remainingZombies) ? 'won' : 'playing';
}

export {
  LAWN_ROWS,
  LAWN_COLS,
  HOUSE_LINE_X,
  ZOMBIE_SPAWN_X,
  STARTING_SUN,
  LEVEL_DEFINITION,
  LEVEL,
  LEVEL_CONFIG,
  getWaves,
  getWave,
  getTotalZombieCount,
  getFinalWave,
  pickSpawnRow,
  isInsideLawn,
  columnCenter,
  rowCenter,
  hasReachedHouse,
  createLevelProgress,
  getRemainingZombiesToSpawn,
  hasAllWavesSpawned,
  advanceWaves,
  getCurrentWaveNumber,
  isFinalWave,
  isLevelCleared,
  getLevelStatus,
};

export default LEVEL_DEFINITION;
