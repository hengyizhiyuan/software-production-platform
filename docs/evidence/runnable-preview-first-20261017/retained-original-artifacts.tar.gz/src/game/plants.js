/**
 * plants.js - the plants capability for the Plants vs. Zombies style web game.
 *
 * Scope of this module (first-version core loop only):
 *   - plant catalogue (sun producer, shooter, freezer, wall, one-shot bomb)
 *   - lawn grid occupancy (one plant per cell)
 *   - seed-packet cost and recharge gating
 *   - plant life cycle: sun production, shooting, fuse detonation, damage, death
 *
 * Anything that is not a plant (sun counter, zombies, level waves, rendering,
 * win/lose evaluation) lives outside this file. No DOM access, no canvas, no
 * timers: this module is deterministic and is driven by an explicit dt.
 *
 * Load model
 *   The file is a single self-contained module. It publishes itself on
 *   `globalThis.PVZ.plants` (classic <script> loading) and it also returns the
 *   exact same object through CommonJS (`require('./game/plants.js')`) so that
 *   Node based checks can exercise it directly. No module-level game state is
 *   kept, therefore several lawn boards may exist side by side.
 *
 * Integration contract (game state always stays outside this module)
 *   board    = createBoard(rows, cols)                    // lawn occupancy
 *   seedBank = createSeedBank()                           // cost / recharge gating
 *   result   = placePlant(board, seedBank, type, row, col, currentSun, nowSeconds)
 *              -> { ok: true,  reason: 'ok', plant, cost }
 *              -> { ok: false, reason: 'out_of_bounds' | 'occupied' |
 *                                       'unknown_plant' | 'recharging' |
 *                                       'insufficient_sun' }
 *              The CALLER subtracts `cost` from the sun counter when ok is true;
 *              this module never touches the sun counter.
 *   update(dt, board, hooks)                              // once per frame
 *
 *   `hooks` (all optional, missing hooks simply disable that effect):
 *     spawnSun({ amount, plant, row, col, x, y })
 *     findTarget(plant) -> zombie|null   // nearest zombie ahead of the plant in its lane
 *     fireProjectile({ row, col, x, y, damage, slows, slowFactor, slowDuration, plant })
 *     explode({ row, col, damage, radius, plant })       // radius in lawn cells
 *     onPlantRemoved(plant, reason)      // reason: 'eaten' | 'exploded' | 'removed'
 *
 *   Zombies (or any other attacker) reduce plant health through
 *     damagePlant(board, plant, amount, hooks)
 *     damagePlantAt(board, row, col, amount, hooks)
 *   Both return { dead: boolean, plant, health }.
 */

(function (root, factory) {
  'use strict';

  var api = factory();

  if (typeof module === 'object' && module !== null && module.exports) {
    module.exports = api;
  }

  if (root) {
    root.PVZ = root.PVZ || {};
    root.PVZ.plants = api;
  }

  /*
   * Executable self-check (Node only).
   *
   * `node src/game/plants.js` exercises the exported plant capability without a
   * DOM, canvas or timers: lawn occupancy, cost and recharge gating, sun
   * production, shooting, slowing, detonation, damage/death and board clearing.
   * The browser load path never reaches this block and it keeps no state.
   */
  var isDirectNodeRun =
    typeof module === 'object' &&
    module !== null &&
    module.exports === api &&
    typeof require === 'function' &&
    typeof process === 'object' &&
    process !== null &&
    typeof process.stdout === 'object' &&
    require.main === module;

  if (isDirectNodeRun) {
    var checked = [];
    var failures = [];
    var check = function (name, condition, detail) {
      checked.push(name);
      if (!condition) {
        failures.push(detail ? name + ' (' + detail + ')' : name);
      }
    };
    var board;
    var bank;
    var placed;
    var events;
    var removed;
    var absorbed;
    var killed;

    /* placement occupies the requested lawn cell */
    board = api.createBoard(5, 9);
    bank = api.createSeedBank();
    placed = api.placePlant(board, bank, 'sunflower', 2, 3, 50, 0);
    check('placePlant accepts an affordable, ready packet', placed.ok === true && !!placed.plant, placed.reason);
    check('placePlant reports the seed cost', placed.cost === 50, String(placed.cost));
    check(
      'plant occupies the requested lawn cell',
      api.getPlantAt(board, 2, 3) === placed.plant &&
        placed.plant.row === 2 &&
        placed.plant.col === 3 &&
        api.getPlantCount(board) === 1
    );

    /* one plant per cell */
    var sameCell = api.placePlant(board, bank, 'peashooter', 2, 3, 500, 0);
    check(
      'a second plant in the same cell is rejected',
      sameCell.ok === false && sameCell.reason === 'occupied',
      sameCell.reason
    );

    /* recharge gating */
    var stillRecharging = api.placePlant(board, bank, 'sunflower', 4, 4, 500, 0);
    check(
      'seed packet recharge gates placement',
      stillRecharging.ok === false && stillRecharging.reason === 'recharging',
      stillRecharging.reason
    );
    api.tickSeedBank(bank, 8);
    check('seed packet is ready again after its cooldown', api.isSeedReady(bank, 'sunflower') === true);

    /* sun cost gating on a fresh lawn */
    var poorBoard = api.createBoard();
    var poorBank = api.createSeedBank();
    var poor = api.placePlant(poorBoard, poorBank, 'peashooter', 0, 0, 25, 0);
    check('insufficient sun blocks placement', poor.ok === false && poor.reason === 'insufficient_sun', poor.reason);
    check(
      'blocked placement leaves the lawn empty',
      api.getPlantAt(poorBoard, 0, 0) === null && api.getPlantCount(poorBoard) === 0
    );
    check('blocked placement keeps the packet ready', api.isSeedReady(poorBank, 'peashooter') === true);
    var unknown = api.placePlant(poorBoard, poorBank, 'torchwood', 0, 0, 500, 0);
    check('unknown plant type is rejected', unknown.ok === false && unknown.reason === 'unknown_plant', unknown.reason);
    var outOfBounds = api.placePlant(poorBoard, poorBank, 'sunflower', -1, 0, 500, 0);
    check(
      'out of bounds placement is rejected',
      outOfBounds.ok === false && outOfBounds.reason === 'out_of_bounds',
      outOfBounds.reason
    );

    /* sunflower produces sun */
    events = [];
    api.update(7, board, {
      spawnSun: function (sun) {
        events.push(sun);
      }
    });
    check('sunflower produces sun', events.length === 1 && events[0].amount === 25, String(events.length));
    check('sun spawn carries its lawn cell', !!events[0] && events[0].row === 2 && events[0].col === 3);

    /* peashooter fires at a lane target */
    var laneBoard = api.createBoard();
    var laneBank = api.createSeedBank();
    var shooter = api.placePlant(laneBoard, laneBank, 'peashooter', 1, 1, 100, 0).plant;
    var shots = [];
    api.update(1.6, laneBoard, {
      findTarget: function (plant) {
        return plant === shooter ? { id: 'zombie-1' } : null;
      },
      fireProjectile: function (shot) {
        shots.push(shot);
      }
    });
    check(
      'peashooter fires when a zombie is in its lane',
      shots.length === 1 && shots[0].damage === 20,
      String(shots.length)
    );
    var idleShots = [];
    api.update(1.6, laneBoard, {
      fireProjectile: function (shot) {
        idleShots.push(shot);
      }
    });
    check('peashooter holds fire when the lane is empty', idleShots.length === 0, String(idleShots.length));

    /* snow pea slows what it hits */
    var snowBoard = api.createBoard();
    var snowBank = api.createSeedBank();
    api.placePlant(snowBoard, snowBank, 'snowpea', 0, 0, 175, 0);
    var snowShots = [];
    api.update(1.6, snowBoard, {
      findTarget: function () {
        return { id: 'zombie-2' };
      },
      fireProjectile: function (shot) {
        snowShots.push(shot);
      }
    });
    check(
      'snow pea fires a slowing projectile',
      snowShots.length === 1 &&
        snowShots[0].slows === true &&
        snowShots[0].slowFactor === 0.5 &&
        snowShots[0].slowDuration === 3
    );

    /* cherry bomb detonates and clears its cell */
    var bombBoard = api.createBoard();
    var bombBank = api.createSeedBank();
    var bomb = api.placePlant(bombBoard, bombBank, 'cherrybomb', 2, 5, 150, 0).plant;
    var blasts = [];
    removed = [];
    api.update(1.1, bombBoard, {
      explode: function (blast) {
        blasts.push(blast);
      },
      onPlantRemoved: function (plant, reason) {
        removed.push(reason);
      }
    });
    check(
      'cherry bomb detonates',
      blasts.length === 1 && blasts[0].damage === 1800 && blasts[0].radius === 1,
      String(blasts.length)
    );
    check('cherry bomb clears its cell', api.getPlantAt(bombBoard, 2, 5) === null && api.getPlantCount(bombBoard) === 0);
    check(
      'cherry bomb removal reason is reported',
      removed.length === 1 && removed[0] === 'exploded' && bomb.alive === false,
      String(removed[0])
    );

    /* damage and death */
    var wallBoard = api.createBoard();
    var wallBank = api.createSeedBank();
    var wall = api.placePlant(wallBoard, wallBank, 'wallnut', 3, 2, 50, 0).plant;
    absorbed = api.damagePlantAt(wallBoard, 3, 2, 100);
    check(
      'wall-nut absorbs damage without dying',
      absorbed.dead === false && absorbed.health === 3900,
      String(absorbed.health)
    );
    removed = [];
    killed = api.damagePlant(wallBoard, wall, 5000, {
      onPlantRemoved: function (plant, reason) {
        removed.push(reason);
      }
    });
    check(
      'plant dies once its health reaches zero',
      killed.dead === true && wall.alive === false && wall.health === 0
    );
    check('dead plant frees its cell', api.getPlantAt(wallBoard, 3, 2) === null && api.getPlantCount(wallBoard) === 0);
    check('eaten plant removal reason is reported', removed.length === 1 && removed[0] === 'eaten', String(removed[0]));

    /* board reset */
    var resetBoard = api.createBoard();
    var resetBank = api.createSeedBank();
    api.placePlant(resetBoard, resetBank, 'sunflower', 0, 0, 50, 0);
    api.placePlant(resetBoard, resetBank, 'wallnut', 1, 1, 500, 0);
    api.clearBoard(resetBoard);
    check(
      'clearBoard removes every plant',
      api.getPlantCount(resetBoard) === 0 &&
        api.getPlantAt(resetBoard, 0, 0) === null &&
        api.getPlantAt(resetBoard, 1, 1) === null
    );

    process.stdout.write(
      'plants self-check: ' + (checked.length - failures.length) + '/' + checked.length + ' passed\n'
    );
    for (var i = 0; i < failures.length; i += 1) {
      process.stdout.write('  FAIL: ' + failures[i] + '\n');
    }
    if (failures.length) {
      process.exitCode = 1;
    } else {
      process.stdout.write('plants self-check: core-loop plant behaviours verified\n');
    }
  }
})(
  typeof globalThis !== 'undefined'
    ? globalThis
    : typeof window !== 'undefined'
      ? window
      : typeof self !== 'undefined'
        ? self
        : this,
  function () {
    'use strict';

    var VERSION = '1.0.0';
    var DEFAULT_ROWS = 5;
    var DEFAULT_COLS = 9;

    /* Monotonic id source only; it is not game state. */
    var idCounter = 0;

    function nextPlantId() {
      idCounter += 1;
      return 'plant-' + idCounter;
    }

    /**
     * Catalogue. Costs, recharge times, sun intervals, fire intervals and health
     * values follow the original game's single-level balance closely. `colors`
     * are handed to the renderer so every plant is drawn with original
     * procedural art instead of ripped sprites.
     */
    var PLANT_TYPES = {
      sunflower: {
        key: 'sunflower',
        name: 'Sunflower',
        cost: 50,
        recharge: 7.5,
        health: 300,
        sunInterval: 24,
        sunAmount: 25,
        firstSun: 6,
        colors: { body: '#f2c14e', accent: '#8bc34a', face: '#5b3a1e' },
        description: 'Produces 25 sun every 24 seconds.'
      },
      peashooter: {
        key: 'peashooter',
        name: 'Peashooter',
        cost: 100,
        recharge: 7.5,
        health: 300,
        fireInterval: 1.5,
        peaDamage: 20,
        colors: { body: '#4caf50', accent: '#2e7d32', face: '#1b5e20' },
        description: 'Fires a pea at the nearest zombie in its lane.'
      },
      wallnut: {
        key: 'wallnut',
        name: 'Wall-nut',
        cost: 50,
        recharge: 30,
        health: 4000,
        colors: { body: '#c8a165', accent: '#8d6e3a', face: '#4e342e' },
        description: 'Soaks up damage and stalls a lane.'
      },
      snowpea: {
        key: 'snowpea',
        name: 'Snow Pea',
        cost: 175,
        recharge: 7.5,
        health: 300,
        fireInterval: 1.5,
        peaDamage: 20,
        slows: true,
        slowFactor: 0.5,
        slowDuration: 3,
        colors: { body: '#4fc3f7', accent: '#0288d1', face: '#01579b' },
        description: 'Fires a frozen pea that slows the zombie it hits.'
      },
      cherrybomb: {
        key: 'cherrybomb',
        name: 'Cherry Bomb',
        cost: 150,
        recharge: 20,
        health: 300,
        fuse: 1,
        blastDamage: 1800,
        blastRadius: 1,
        colors: { body: '#e53935', accent: '#b71c1c', face: '#3e2723' },
        description: 'Detonates after a short fuse and damages nearby zombies.'
      }
    };

    /* Seed-packet order shown in the seed bank, left to right. */
    var SEED_ORDER = ['sunflower', 'peashooter', 'wallnut', 'snowpea', 'cherrybomb'];

    function getPlantType(typeKey) {
      if (typeof typeKey !== 'string') {
        return null;
      }
      return Object.prototype.hasOwnProperty.call(PLANT_TYPES, typeKey)
        ? PLANT_TYPES[typeKey]
        : null;
    }

    /* ---------------------------------------------------------------- board */

    function createBoard(rows, cols) {
      var rowCount = typeof rows === 'number' && rows > 0 ? Math.floor(rows) : DEFAULT_ROWS;
      var colCount = typeof cols === 'number' && cols > 0 ? Math.floor(cols) : DEFAULT_COLS;
      var grid = [];
      var r;
      var c;
      var rowCells;

      for (r = 0; r < rowCount; r += 1) {
        rowCells = [];
        for (c = 0; c < colCount; c += 1) {
          rowCells.push(null);
        }
        grid.push(rowCells);
      }

      return {
        rows: rowCount,
        cols: colCount,
        grid: grid,
        plants: []
      };
    }

    function inBounds(board, row, col) {
      return (
        !!board &&
        typeof row === 'number' &&
        typeof col === 'number' &&
        row >= 0 &&
        row < board.rows &&
        col >= 0 &&
        col < board.cols
      );
    }

    function getPlantAt(board, row, col) {
      if (!inBounds(board, row, col)) {
        return null;
      }
      return board.grid[row][col];
    }

    function addPlant(board, plant) {
      if (!board || !plant) {
        return null;
      }
      board.grid[plant.row][plant.col] = plant;
      board.plants.push(plant);
      return plant;
    }

    function getPlantCount(board) {
      return board && board.plants ? board.plants.length : 0;
    }

    /* --------------------------------------------------------------- plants */

    function createPlant(typeKey, row, col, now) {
      var def = getPlantType(typeKey);
      if (!def) {
        return null;
      }

      var startedAt = typeof now === 'number' ? now : 0;

      return {
        id: nextPlantId(),
        type: def.key,
        row: row,
        col: col,
        x: col,
        y: row,
        plantedAt: startedAt,
        age: 0,
        health: def.health,
        maxHealth: def.health,
        alive: true,
        shooting: false,
        sunTimer: def.sunInterval ? (typeof def.firstSun === 'number' ? def.firstSun : def.sunInterval) : 0,
        fireTimer: 0,
        fuseTimer: typeof def.fuse === 'number' ? def.fuse : 0
      };
    }

    /* ------------------------------------------------------------ seed bank */

    function createSeedBank() {
      var packets = [];
      var i;
      var def;

      for (i = 0; i < SEED_ORDER.length; i += 1) {
        def = PLANT_TYPES[SEED_ORDER[i]];
        packets.push({
          type: def.key,
          name: def.name,
          cost: def.cost,
          cooldown: def.recharge,
          remaining: 0,
          ready: true
        });
      }

      return packets;
    }

    function getSeedPacket(seedBank, typeKey) {
      var i;

      if (!seedBank || !seedBank.length) {
        return null;
      }

      for (i = 0; i < seedBank.length; i += 1) {
        if (seedBank[i].type === typeKey) {
          return seedBank[i];
        }
      }

      return null;
    }

    function isSeedReady(seedBank, typeKey) {
      var packet = getSeedPacket(seedBank, typeKey);
      return !!packet && packet.remaining <= 0;
    }

    function startRecharge(seedBank, typeKey) {
      var packet = getSeedPacket(seedBank, typeKey);
      if (!packet) {
        return false;
      }
      packet.remaining = packet.cooldown;
      packet.ready = false;
      return true;
    }

    function tickSeedBank(seedBank, dt) {
      var i;
      var packet;

      if (!seedBank || !seedBank.length || !(dt > 0)) {
        return seedBank;
      }

      for (i = 0; i < seedBank.length; i += 1) {
        packet = seedBank[i];
        if (packet.remaining > 0) {
          packet.remaining -= dt;
          if (packet.remaining <= 0) {
            packet.remaining = 0;
          }
        }
        packet.ready = packet.remaining <= 0;
      }

      return seedBank;
    }

    /* ------------------------------------------------------------- placement */

    function canPlace(board, row, col) {
      if (!board) {
        return { ok: false, reason: 'no_board' };
      }
      if (!inBounds(board, row, col)) {
        return { ok: false, reason: 'out_of_bounds' };
      }
      if (board.grid[row][col]) {
        return { ok: false, reason: 'occupied' };
      }
      return { ok: true, reason: 'ok' };
    }

    /**
     * Place a plant if the cell is free, the packet has recharged and the
     * player can afford it. The caller deducts `cost` from the sun counter.
     */
    function placePlant(board, seedBank, typeKey, row, col, availableSun, now) {
      var def = getPlantType(typeKey);
      var cell;
      var packet;
      var plant;

      if (!def) {
        return { ok: false, reason: 'unknown_plant' };
      }

      cell = canPlace(board, row, col);
      if (!cell.ok) {
        return cell;
      }

      packet = getSeedPacket(seedBank, def.key);
      if (packet && packet.remaining > 0) {
        return { ok: false, reason: 'recharging' };
      }

      if (typeof availableSun === 'number' && availableSun < def.cost) {
        return { ok: false, reason: 'insufficient_sun' };
      }

      plant = createPlant(def.key, row, col, now);
      addPlant(board, plant);

      if (packet) {
        packet.remaining = packet.cooldown;
        packet.ready = false;
      }

      return { ok: true, reason: 'ok', plant: plant, cost: def.cost };
    }

    /* ------------------------------------------------------- damage / death */

    function removePlant(board, plant, reason, hooks) {
      var index;

      if (!board || !plant || !plant.alive) {
        return false;
      }

      index = board.plants.indexOf(plant);
      if (index >= 0) {
        board.plants.splice(index, 1);
      }

      if (board.grid[plant.row] && board.grid[plant.row][plant.col] === plant) {
        board.grid[plant.row][plant.col] = null;
      }

      plant.alive = false;
      plant.health = 0;

      if (hooks && typeof hooks.onPlantRemoved === 'function') {
        hooks.onPlantRemoved(plant, reason || 'removed');
      }

      return true;
    }

    function damagePlant(board, plant, amount, hooks) {
      if (!plant || !plant.alive || !(amount > 0)) {
        return { dead: false, plant: plant || null, health: plant ? plant.health : 0 };
      }

      plant.health -= amount;

      if (plant.health <= 0) {
        plant.health = 0;
        removePlant(board, plant, 'eaten', hooks);
        return { dead: true, plant: plant, health: 0 };
      }

      return { dead: false, plant: plant, health: plant.health };
    }

    function damagePlantAt(board, row, col, amount, hooks) {
      var plant = getPlantAt(board, row, col);
      if (!plant) {
        return { dead: false, plant: null, health: 0 };
      }
      return damagePlant(board, plant, amount, hooks);
    }

    /* -------------------------------------------------------------- update */

    function stepPlant(plant, dt, board, hooks) {
      var def = getPlantType(plant.type);
      var target;

      if (!def) {
        return;
      }

      plant.age += dt;
      plant.shooting = false;

      if (def.sunInterval) {
        plant.sunTimer -= dt;
        if (plant.sunTimer <= 0) {
          plant.sunTimer = def.sunInterval;
          if (typeof hooks.spawnSun === 'function') {
            hooks.spawnSun({
              amount: def.sunAmount,
              plant: plant,
              row: plant.row,
              col: plant.col,
              x: plant.col + 0.5,
              y: plant.row + 0.5
            });
          }
        }
      }

      if (def.fireInterval) {
        target = typeof hooks.findTarget === 'function' ? hooks.findTarget(plant) : null;
        if (target) {
          plant.fireTimer -= dt;
          if (plant.fireTimer <= 0) {
            plant.fireTimer = def.fireInterval;
            plant.shooting = true;
            if (typeof hooks.fireProjectile === 'function') {
              hooks.fireProjectile({
                row: plant.row,
                col: plant.col,
                x: plant.col + 0.75,
                y: plant.row + 0.5,
                damage: def.peaDamage,
                slows: !!def.slows,
                slowFactor: typeof def.slowFactor === 'number' ? def.slowFactor : 1,
                slowDuration: typeof def.slowDuration === 'number' ? def.slowDuration : 0,
                plant: plant
              });
            }
          }
        } else if (plant.fireTimer < 0) {
          plant.fireTimer = 0;
        }
      }

      if (def.fuse) {
        plant.fuseTimer -= dt;
        if (plant.fuseTimer <= 0) {
          if (typeof hooks.explode === 'function') {
            hooks.explode({
              row: plant.row,
              col: plant.col,
              damage: def.blastDamage,
              radius: def.blastRadius,
              plant: plant
            });
          }
          removePlant(board, plant, 'exploded', hooks);
        }
      }
    }

    /**
     * Advance every living plant by `dt` seconds.
     * Iteration is index based and backwards safe because removal happens
     * in place and the loop re-checks `alive`.
     */
    function update(dt, board, hooks) {
      var safeHooks = hooks || {};
      var plants;
      var i;
      var plant;

      if (!board || !board.plants || !(dt > 0)) {
        return board;
      }

      plants = board.plants.slice();

      for (i = 0; i < plants.length; i += 1) {
        plant = plants[i];
        if (plant && plant.alive) {
          stepPlant(plant, dt, board, safeHooks);
        }
      }

      return board;
    }

    function clearBoard(board, hooks) {
      var plants;
      var i;

      if (!board) {
        return board;
      }

      plants = board.plants.slice();
      for (i = 0; i < plants.length; i += 1) {
        removePlant(board, plants[i], 'removed', hooks);
      }

      return board;
    }

    return {
      VERSION: VERSION,
      DEFAULT_ROWS: DEFAULT_ROWS,
      DEFAULT_COLS: DEFAULT_COLS,
      PLANT_TYPES: PLANT_TYPES,
      SEED_ORDER: SEED_ORDER,
      getPlantType: getPlantType,
      createBoard: createBoard,
      inBounds: inBounds,
      getPlantAt: getPlantAt,
      getPlantCount: getPlantCount,
      createPlant: createPlant,
      createSeedBank: createSeedBank,
      getSeedPacket: getSeedPacket,
      isSeedReady: isSeedReady,
      startRecharge: startRecharge,
      tickSeedBank: tickSeedBank,
      canPlace: canPlace,
      placePlant: placePlant,
      damagePlant: damagePlant,
      damagePlantAt: damagePlantAt,
      removePlant: removePlant,
      update: update,
      clearBoard: clearBoard
    };
  }
);
