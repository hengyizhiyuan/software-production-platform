/**
 * Sun capability for the Plants vs. Zombies style web game (first version).
 *
 * This module owns one narrow slice of the single-level core loop:
 *   - the data shape of a collectible sun token (value, falling motion, lifetime),
 *   - spawning of sky suns on an interval and of suns produced by sunflowers,
 *   - resolving a click/tap on the lawn to a sun token and crediting the shared
 *     sun counter that gates plant placement.
 *
 * It is deliberately renderer-agnostic: it keeps only plain data plus the small
 * amount of motion/lifetime bookkeeping described above. Drawing lives in
 * src/render/renderer.js and input wiring lives in src/main.js.
 *
 * All functions are side-effect free with respect to the DOM, so the sun rules
 * can be exercised without a browser.
 */

/** Sun gained by collecting one token (the classic PvZ unit). */
export const SUN_VALUE = 25;

/** Seconds between two suns falling from the sky in the first version. */
export const SKY_SUN_SPAWN_INTERVAL = 10;

/** Seconds a sunflower waits between producing suns (tracked by the caller). */
export const SUNFLOWER_SUN_INTERVAL = 24;

/** Vertical speed, in world units per second, of a sun that is still falling. */
export const SUN_FALL_SPEED = 60;

/** Seconds a landed sun stays collectible before it fades away. */
export const SUN_LANDED_LIFETIME = 9;

/** Radius, in world units, that counts as a direct hit on a sun token. */
export const SUN_COLLECT_RADIUS = 26;

/**
 * Accepted field names for the shared sun counter. The counter lives on the
 * shared game state (src/game/state.js); this module reads whatever counter key
 * the state already uses and writes back to that same key, so the sun rules and
 * the rest of the loop cannot drift onto two different numbers.
 */
export const SUN_COUNTER_KEYS = Object.freeze(['sun', 'sunCount']);

let sunSequence = 0;

/**
 * Create one collectible sun token.
 *
 * @param {{x?: number, y?: number, targetY?: number, value?: number, source?: string}} [options]
 * @returns {{id: string, kind: string, source: string, x: number, y: number,
 *   targetY: number, value: number, falling: boolean, landedAge: number,
 *   collected: boolean}}
 */
export function createSun(options = {}) {
  const {
    x = 0,
    y = 0,
    targetY = y,
    value = SUN_VALUE,
    source = 'sky',
  } = options;

  sunSequence += 1;
  const startY = Number.isFinite(y) ? y : 0;
  const landingY = Number.isFinite(targetY) ? targetY : startY;

  return {
    id: `sun-${sunSequence}`,
    kind: 'sun',
    source,
    x: Number.isFinite(x) ? x : 0,
    y: startY,
    targetY: landingY,
    value: Number.isFinite(value) ? value : SUN_VALUE,
    falling: startY < landingY,
    landedAge: 0,
    collected: false,
  };
}

/**
 * Advance one sun token by `dt` seconds: fall towards its landing height, then
 * start ageing on the lawn.
 *
 * @param {object} sun
 * @param {number} dt
 * @returns {object} the same sun token
 */
export function updateSun(sun, dt) {
  if (!sun || sun.collected) return sun;
  const step = Number.isFinite(dt) && dt > 0 ? dt : 0;

  if (sun.falling) {
    sun.y += SUN_FALL_SPEED * step;
    if (sun.y >= sun.targetY) {
      sun.y = sun.targetY;
      sun.falling = false;
      sun.landedAge = 0;
    }
  } else {
    sun.landedAge += step;
  }

  return sun;
}

/**
 * @param {object} sun
 * @returns {boolean} true when a landed sun has outlived its collectible window
 */
export function isSunExpired(sun) {
  return Boolean(sun && !sun.collected && !sun.falling && sun.landedAge >= SUN_LANDED_LIFETIME);
}

/**
 * Advance every sun token in a list and drop the ones that were collected or
 * faded away.
 *
 * @param {object[]} suns
 * @param {number} dt
 * @returns {{expired: object[]}} tokens removed because their lifetime ended
 */
export function updateSuns(suns, dt) {
  const expired = [];
  if (!Array.isArray(suns)) return { expired };

  const step = Number.isFinite(dt) && dt > 0 ? dt : 0;

  for (let index = suns.length - 1; index >= 0; index -= 1) {
    const sun = suns[index];
    if (!sun) {
      suns.splice(index, 1);
      continue;
    }

    updateSun(sun, step);
    const expiredNow = !sun.collected && isSunExpired(sun);

    if (sun.collected || expiredNow) {
      suns.splice(index, 1);
      if (expiredNow) expired.push(sun);
    }
  }

  return { expired };
}

/**
 * Find the closest collectible sun token within `radius` of a point.
 *
 * @param {object[]} suns
 * @param {number} x
 * @param {number} y
 * @param {number} [radius]
 * @returns {object|null}
 */
export function findSunAt(suns, x, y, radius = SUN_COLLECT_RADIUS) {
  if (!Array.isArray(suns)) return null;

  const limit = Number.isFinite(radius) ? radius : SUN_COLLECT_RADIUS;
  const limitSquared = limit * limit;

  let best = null;
  let bestDistanceSquared = Infinity;

  for (const sun of suns) {
    if (!sun || sun.collected) continue;
    const dx = sun.x - x;
    const dy = sun.y - y;
    const distanceSquared = dx * dx + dy * dy;
    if (distanceSquared <= limitSquared && distanceSquared < bestDistanceSquared) {
      best = sun;
      bestDistanceSquared = distanceSquared;
    }
  }

  return best;
}

/**
 * Remove one sun token from a list.
 *
 * @param {object[]} suns
 * @param {object} sun
 * @returns {boolean} whether the token was present
 */
export function removeSun(suns, sun) {
  if (!Array.isArray(suns) || !sun) return false;
  const index = suns.indexOf(sun);
  if (index === -1) return false;
  suns.splice(index, 1);
  return true;
}

/**
 * Read the shared sun counter from game state.
 *
 * @param {object} state
 * @returns {number}
 */
export function readSunCounter(state) {
  if (!state || typeof state !== 'object') return 0;
  for (const key of SUN_COUNTER_KEYS) {
    if (Number.isFinite(state[key])) return state[key];
  }
  return 0;
}

/**
 * Write the shared sun counter on game state, reusing the key the state already
 * uses (or the primary key when the state has no counter yet).
 *
 * @param {object} state
 * @param {number} value
 * @returns {number} the stored value
 */
export function writeSunCounter(state, value) {
  if (!state || typeof state !== 'object') return 0;

  const next = Math.max(0, Math.round(Number.isFinite(value) ? value : 0));
  let key = SUN_COUNTER_KEYS[0];
  for (const candidate of SUN_COUNTER_KEYS) {
    if (Number.isFinite(state[candidate])) {
      key = candidate;
      break;
    }
  }

  state[key] = next;
  return next;
}

/**
 * Add (or, with a negative amount, spend) sun on the shared counter.
 *
 * @param {object} state
 * @param {number} amount
 * @returns {number} the updated counter value
 */
export function creditSun(state, amount) {
  const delta = Number.isFinite(amount) ? amount : 0;
  return writeSunCounter(state, readSunCounter(state) + delta);
}

/**
 * Collect a single sun token: mark it collected, detach it from the lawn and
 * credit its value to the shared sun counter.
 *
 * @param {object} state
 * @param {object} sun
 * @returns {number} sun gained (0 when the token was already gone)
 */
export function collectSun(state, sun) {
  if (!sun || sun.collected) return 0;

  sun.collected = true;
  if (state && Array.isArray(state.suns)) removeSun(state.suns, sun);

  const gained = Number.isFinite(sun.value) ? sun.value : SUN_VALUE;
  creditSun(state, gained);
  return gained;
}

/**
 * Build the sun system for one level run.
 *
 * The system keeps the list of live sun tokens on `state.suns` and the running
 * total on the shared sun counter (see SUN_COUNTER_KEYS), so a renderer or HUD
 * can read `state.suns` / `readSunCounter(state)` at any time.
 *
 * @param {object} [state] shared game state
 * @param {{random?: () => number, collectRadius?: number, skyInterval?: number,
 *   skyArea?: {minX?: number, maxX?: number, topY?: number, landingMinY?: number,
 *   landingMaxY?: number}}} [options]
 */
export function createSunSystem(state = {}, options = {}) {
  if (!state || typeof state !== 'object') {
    throw new TypeError('createSunSystem requires a shared game state object');
  }

  const {
    random = Math.random,
    collectRadius = SUN_COLLECT_RADIUS,
    skyInterval = SKY_SUN_SPAWN_INTERVAL,
  } = options;

  const skyArea = {
    minX: 60,
    maxX: 740,
    topY: -24,
    landingMinY: 120,
    landingMaxY: 210,
    ...options.skyArea,
  };

  if (!Array.isArray(state.suns)) state.suns = [];
  if (!SUN_COUNTER_KEYS.some((key) => Number.isFinite(state[key]))) {
    writeSunCounter(state, 0);
  }

  const interval = Number.isFinite(skyInterval) && skyInterval > 0
    ? skyInterval
    : SKY_SUN_SPAWN_INTERVAL;

  let skyTimer = 0;

  function listSuns() {
    return state.suns;
  }

  function randomBetween(min, max) {
    const low = Math.min(min, max);
    const high = Math.max(min, max);
    const unit = Number.isFinite(random()) ? random() : 0;
    return low + (high - low) * unit;
  }

  /**
   * Drop one sun from the sky and return it.
   */
  function spawnSkySun(overrides = {}) {
    const sun = createSun({
      x: Number.isFinite(overrides.x) ? overrides.x : randomBetween(skyArea.minX, skyArea.maxX),
      y: Number.isFinite(overrides.y) ? overrides.y : skyArea.topY,
      targetY: Number.isFinite(overrides.targetY)
        ? overrides.targetY
        : randomBetween(skyArea.landingMinY, skyArea.landingMaxY),
      value: Number.isFinite(overrides.value) ? overrides.value : SUN_VALUE,
      source: 'sky',
    });

    listSuns().push(sun);
    return sun;
  }

  /**
   * Emit one sun from a sunflower (or any producing plant) at the plant's cell.
   */
  function spawnPlantSun(plant, overrides = {}) {
    const baseX = plant && Number.isFinite(plant.x) ? plant.x : 0;
    const baseY = plant && Number.isFinite(plant.y) ? plant.y : 0;

    const sun = createSun({
      x: Number.isFinite(overrides.x) ? overrides.x : baseX + randomBetween(-6, 6),
      y: Number.isFinite(overrides.y) ? overrides.y : baseY,
      targetY: Number.isFinite(overrides.targetY) ? overrides.targetY : baseY + 22,
      value: Number.isFinite(overrides.value) ? overrides.value : SUN_VALUE,
      source: 'sunflower',
    });

    listSuns().push(sun);
    return sun;
  }

  /**
   * Advance the sun system by `dt` seconds.
   *
   * @returns {{spawned: object[], expired: object[], sunCount: number}}
   */
  function update(dt) {
    const step = Number.isFinite(dt) && dt > 0 ? dt : 0;

    const spawned = [];
    skyTimer += step;

    // A long frame may cover several spawn intervals; cap the catch-up so a
    // paused tab cannot flood the lawn.
    let guard = 0;
    while (skyTimer >= interval && guard < 8) {
      skyTimer -= interval;
      spawned.push(spawnSkySun());
      guard += 1;
    }
    if (guard >= 8 && skyTimer >= interval) skyTimer = 0;

    const { expired } = updateSuns(listSuns(), step);

    return { spawned, expired, sunCount: readSunCounter(state) };
  }

  /**
   * Resolve a pointer position on the lawn to a sun and collect it.
   *
   * @returns {number} sun gained (0 when nothing was hit)
   */
  function collectAt(x, y) {
    const sun = findSunAt(listSuns(), x, y, collectRadius);
    if (!sun) return 0;
    return collectSun(state, sun);
  }

  /**
   * Collect a specific sun token by id.
   *
   * @returns {number} sun gained (0 when the token is gone)
   */
  function collectById(id) {
    const sun = listSuns().find((candidate) => candidate && candidate.id === id);
    if (!sun) return 0;
    return collectSun(state, sun);
  }

  /**
   * Reset the sun layer for a fresh level run.
   */
  function reset() {
    state.suns.length = 0;
    skyTimer = 0;
    writeSunCounter(state, 0);
  }

  return {
    skyInterval: interval,
    collectRadius,
    get suns() {
      return state.suns;
    },
    getSunCount: () => readSunCounter(state),
    spawnSkySun,
    spawnPlantSun,
    update,
    collectAt,
    collectById,
    reset,
  };
}

export default {
  SUN_VALUE,
  SKY_SUN_SPAWN_INTERVAL,
  SUNFLOWER_SUN_INTERVAL,
  SUN_FALL_SPEED,
  SUN_LANDED_LIFETIME,
  SUN_COLLECT_RADIUS,
  SUN_COUNTER_KEYS,
  createSun,
  updateSun,
  isSunExpired,
  updateSuns,
  findSunAt,
  removeSun,
  readSunCounter,
  writeSunCounter,
  creditSun,
  collectSun,
  createSunSystem,
};
