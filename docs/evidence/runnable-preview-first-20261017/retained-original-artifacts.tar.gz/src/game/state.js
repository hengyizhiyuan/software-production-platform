/**
 * Core world state for the Plants vs. Zombies style single-level web game.
 *
 * This module owns the shared, plain-data simulation state (sun bank, lawn grid,
 * planted plants, advancing zombies, sun tokens, wave progress, win/lose status)
 * together with the pure helpers that read and mutate it.
 *
 * It deliberately has no imports and no DOM access, so the simulation modules
 * (sun, plants, zombies, level), the canvas renderer and Node based tests can all
 * share the exact same state model.
 *
 * Units: positions are canvas pixels, times are seconds, speeds are pixels/second.
 */

/* ------------------------------------------------------------------------- */
/* Layout and tuning constants                                               */
/* ------------------------------------------------------------------------- */

/** Lawn grid dimensions: the classic front lawn is 5 rows by 9 columns. */
export const GRID_ROWS = 5;
export const GRID_COLS = 9;

/** Pixel geometry of the lawn, shared with the renderer. */
export const LAYOUT = Object.freeze({
  boardX: 250,
  boardY: 90,
  cellWidth: 80,
  cellHeight: 96,
  rows: GRID_ROWS,
  cols: GRID_COLS,
});

export const BOARD_WIDTH = LAYOUT.boardX + LAYOUT.cols * LAYOUT.cellWidth;
export const BOARD_HEIGHT = LAYOUT.boardY + LAYOUT.rows * LAYOUT.cellHeight;

/** World x of the house wall: a zombie that reaches it ends the level in a loss. */
export const HOUSE_LINE_X = LAYOUT.boardX - 48;

/** Zombies enter from beyond the right edge of the lawn. */
export const ZOMBIE_START_X = BOARD_WIDTH + 40;

export const GAME_STATUS = Object.freeze({
  PLAYING: 'playing',
  WON: 'won',
  LOST: 'lost',
});

/** Sun economy defaults. */
export const STARTING_SUN = 50;
export const SUN_VALUE = 25;
export const SUN_LIFETIME = 9;

/** Combat defaults, used when a definition does not provide its own numbers. */
export const DEFAULT_PLANT_HEALTH = 300;
export const DEFAULT_ZOMBIE_HEALTH = 100;
export const DEFAULT_ZOMBIE_SPEED = 12;
export const DEFAULT_ZOMBIE_DAMAGE = 1;
export const DEFAULT_ZOMBIE_BITE_INTERVAL = 0.5;

/** Coerce a possibly-missing numeric value to a finite number. */
function asNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

/* ------------------------------------------------------------------------- */
/* State creation and lifecycle                                              */
/* ------------------------------------------------------------------------- */

/**
 * Create a fresh world state for one playable level.
 *
 * @param {object} [options]
 * @param {number} [options.rows] lawn rows (defaults to {@link GRID_ROWS})
 * @param {number} [options.cols] lawn columns (defaults to {@link GRID_COLS})
 * @param {number} [options.sun] starting sun bank (defaults to {@link STARTING_SUN})
 * @param {object} [options.layout] renderer layout (defaults to {@link LAYOUT})
 * @param {string[]} [options.seeds] seed packet types shown in the seed bank
 * @returns {object} mutable game state
 */
export function createGameState(options = {}) {
  const rows = Math.max(1, Math.trunc(asNumber(options.rows, GRID_ROWS)));
  const cols = Math.max(1, Math.trunc(asNumber(options.cols, GRID_COLS)));
  const startingSun = Math.max(0, asNumber(options.sun, STARTING_SUN));

  return {
    status: GAME_STATUS.PLAYING,
    endReason: null,
    elapsed: 0,
    sun: startingSun,
    startingSun,
    rows,
    cols,
    layout: options.layout || LAYOUT,
    seeds: Array.isArray(options.seeds) ? options.seeds.slice() : [],
    plants: [],
    zombies: [],
    projectiles: [],
    sunTokens: [],
    seedCooldowns: {},
    selectedSeed: null,
    waveIndex: 0,
    totalWaves: Math.max(0, Math.trunc(asNumber(options.totalWaves, 0))),
    stats: {
      sunCollected: 0,
      plantsPlanted: 0,
      plantsLost: 0,
      zombiesSpawned: 0,
      zombiesKilled: 0,
    },
    nextEntityId: 1,
  };
}

/** Alias of {@link createGameState} for callers that prefer the "initial" name. */
export const createInitialState = createGameState;

/**
 * Reset an existing state object in place (used by "play again").
 * The identity of the object is preserved so held references stay valid.
 */
export function resetGameState(state, options = {}) {
  if (!state) return null;
  const fresh = createGameState({
    rows: state.rows,
    cols: state.cols,
    sun: options.sun,
    layout: options.layout || state.layout,
    seeds: options.seeds || state.seeds,
    totalWaves: options.totalWaves,
  });
  Object.keys(state).forEach((key) => {
    delete state[key];
  });
  Object.assign(state, fresh);
  return state;
}

/** Allocate the next entity id for plants, zombies and sun tokens. */
export function nextEntityId(state) {
  if (!state) return 0;
  const id = Math.max(1, Math.trunc(asNumber(state.nextEntityId, 1)));
  state.nextEntityId = id + 1;
  return id;
}

export function isPlaying(state) {
  return Boolean(state) && state.status === GAME_STATUS.PLAYING;
}

export function isGameOver(state) {
  return Boolean(state) && state.status !== GAME_STATUS.PLAYING;
}

/**
 * Move the level to a terminal or playing status. A finished level is never
 * silently flipped to the opposite outcome.
 */
export function setStatus(state, status, reason = null) {
  if (!state) return null;
  const known =
    status === GAME_STATUS.PLAYING || status === GAME_STATUS.WON || status === GAME_STATUS.LOST;
  if (!known) return state.status;
  if (state.status !== GAME_STATUS.PLAYING && state.status !== status) return state.status;
  state.status = status;
  state.endReason = status === GAME_STATUS.PLAYING ? null : reason;
  return state.status;
}

/** Win condition: every zombie of every wave has been cleared. */
export function markWon(state, reason = 'all_waves_cleared') {
  return setStatus(state, GAME_STATUS.WON, reason);
}

/** Lose condition: a zombie walked past the house wall. */
export function markLost(state, reason = 'zombie_reached_house') {
  return setStatus(state, GAME_STATUS.LOST, reason);
}

/* ------------------------------------------------------------------------- */
/* Sun bank                                                                  */
/* ------------------------------------------------------------------------- */

/** Add collected sun to the bank and return the new total. */
export function addSun(state, amount) {
  if (!state) return 0;
  const value = asNumber(amount, 0);
  if (value <= 0) return state.sun;
  state.sun += value;
  return state.sun;
}

/** Whether the bank currently covers `cost`. */
export function canAfford(state, cost) {
  if (!state) return false;
  return state.sun >= Math.max(0, asNumber(cost, 0));
}

/** Deduct `cost` if affordable. Returns true when the sun was spent. */
export function spendSun(state, cost) {
  if (!state) return false;
  const price = Math.max(0, asNumber(cost, 0));
  if (state.sun < price) return false;
  state.sun -= price;
  return true;
}

/* ------------------------------------------------------------------------- */
/* Lawn grid                                                                 */
/* ------------------------------------------------------------------------- */

export function isInsideGrid(state, row, col) {
  if (!state) return false;
  return (
    Number.isInteger(row) &&
    Number.isInteger(col) &&
    row >= 0 &&
    col >= 0 &&
    row < state.rows &&
    col < state.cols
  );
}

/** Stable string key for a lawn cell. */
export function cellKey(row, col) {
  return `${row}:${col}`;
}

/** Centre point of a lawn cell in canvas pixels. */
export function cellCenter(row, col, layout = LAYOUT) {
  const grid = layout || LAYOUT;
  return {
    x: grid.boardX + col * grid.cellWidth + grid.cellWidth / 2,
    y: grid.boardY + row * grid.cellHeight + grid.cellHeight / 2,
  };
}

/** Convert a canvas point into a lawn cell, or null when outside the lawn. */
export function pointToCell(x, y, layout = LAYOUT) {
  const grid = layout || LAYOUT;
  const px = asNumber(x, Number.NaN);
  const py = asNumber(y, Number.NaN);
  if (!Number.isFinite(px) || !Number.isFinite(py)) return null;
  const col = Math.floor((px - grid.boardX) / grid.cellWidth);
  const row = Math.floor((py - grid.boardY) / grid.cellHeight);
  if (row < 0 || col < 0 || row >= grid.rows || col >= grid.cols) return null;
  return { row, col };
}

/* ------------------------------------------------------------------------- */
/* Seed packets and plants                                                   */
/* ------------------------------------------------------------------------- */

/** Resolve a seed packet / plant definition to its type key. */
export function getSeedType(seed) {
  if (!seed) return null;
  if (typeof seed === 'string') return seed;
  return seed.type || seed.seedType || seed.id || seed.key || null;
}

function seedCost(seed) {
  if (!seed || typeof seed !== 'object') return 0;
  return Math.max(0, asNumber(seed.cost, 0));
}

function seedRecharge(seed) {
  if (!seed || typeof seed !== 'object') return 0;
  return Math.max(0, asNumber(seed.recharge, 0));
}

/** Plant occupying a cell, or null. */
export function getPlantAt(state, row, col) {
  if (!state) return null;
  return state.plants.find((plant) => plant.row === row && plant.col === col) || null;
}

export function getPlantById(state, id) {
  if (!state) return null;
  return state.plants.find((plant) => plant.id === id) || null;
}

/** Remaining seed-packet recharge for a plant type, in seconds. */
export function getSeedRecharge(state, seedType) {
  if (!state || !seedType) return 0;
  const remaining = asNumber(state.seedCooldowns[seedType], 0);
  return remaining > 0 ? remaining : 0;
}

/**
 * Decide whether a seed packet can be planted in a cell.
 *
 * @returns {{ok: boolean, reason: string|null}} reason is one of
 *   'missing_state' | 'unknown_plant' | 'game_over' | 'outside_lawn' |
 *   'cell_occupied' | 'recharging' | 'not_enough_sun'
 */
export function canPlacePlant(state, seed, row, col) {
  const seedType = getSeedType(seed);
  if (!state) return { ok: false, reason: 'missing_state' };
  if (!seedType) return { ok: false, reason: 'unknown_plant' };
  if (!isPlaying(state)) return { ok: false, reason: 'game_over' };
  if (!isInsideGrid(state, row, col)) return { ok: false, reason: 'outside_lawn' };
  if (getPlantAt(state, row, col)) return { ok: false, reason: 'cell_occupied' };
  if (getSeedRecharge(state, seedType) > 0) return { ok: false, reason: 'recharging' };
  if (!canAfford(state, seedCost(seed))) return { ok: false, reason: 'not_enough_sun' };
  return { ok: true, reason: null };
}

/**
 * Plant a seed packet: validates placement, spends sun, occupies the cell and
 * starts the seed packet recharge.
 *
 * @returns {{ok: boolean, reason: string|null, plant: object|null}}
 */
export function placePlant(state, seed, row, col) {
  const verdict = canPlacePlant(state, seed, row, col);
  if (!verdict.ok) return { ok: false, reason: verdict.reason, plant: null };

  const seedType = getSeedType(seed);
  spendSun(state, seedCost(seed));

  const center = cellCenter(row, col, state.layout || LAYOUT);
  const requestedHealth =
    seed && typeof seed === 'object' ? seed.health ?? seed.maxHealth : undefined;
  const maxHealth = Math.max(1, asNumber(requestedHealth, DEFAULT_PLANT_HEALTH));

  const plant = {
    id: nextEntityId(state),
    type: seedType,
    row,
    col,
    x: center.x,
    y: center.y,
    health: maxHealth,
    maxHealth,
    attackTimer: 0,
    definition: seed && typeof seed === 'object' ? seed : null,
  };

  state.plants.push(plant);
  state.stats.plantsPlanted += 1;

  const recharge = seedRecharge(seed);
  if (recharge > 0) state.seedCooldowns[seedType] = recharge;

  return { ok: true, reason: null, plant };
}

/**
 * Remove a plant from the lawn. Pass `{ eaten: true }` when a zombie ate it so
 * the loss counter increments.
 */
export function removePlant(state, plantId, options = {}) {
  if (!state) return null;
  const index = state.plants.findIndex((plant) => plant.id === plantId);
  if (index === -1) return null;
  const [plant] = state.plants.splice(index, 1);
  if (options && options.eaten) state.stats.plantsLost += 1;
  return plant;
}

/* ------------------------------------------------------------------------- */
/* Sun tokens on the lawn                                                    */
/* ------------------------------------------------------------------------- */

/** Add a falling/collectable sun token. */
export function addSunToken(state, token = {}) {
  if (!state) return null;
  const x = asNumber(token.x, 0);
  const y = asNumber(token.y, 0);
  const sunToken = {
    id: nextEntityId(state),
    x,
    y,
    targetY: asNumber(token.targetY, y),
    vy: asNumber(token.vy, 0),
    value: Math.max(0, asNumber(token.value, SUN_VALUE)),
    lifetime: Math.max(0, asNumber(token.lifetime, SUN_LIFETIME)),
    age: 0,
  };
  state.sunTokens.push(sunToken);
  return sunToken;
}

export function getSunTokenById(state, tokenId) {
  if (!state) return null;
  return state.sunTokens.find((token) => token.id === tokenId) || null;
}

/**
 * Collect a sun token: it leaves the lawn, its value enters the sun bank and the
 * collected counter advances. Returns the collected value (0 when not found).
 */
export function collectSunToken(state, tokenId) {
  if (!state) return 0;
  const index = state.sunTokens.findIndex((token) => token.id === tokenId);
  if (index === -1) return 0;
  const [token] = state.sunTokens.splice(index, 1);
  const value = Math.max(0, asNumber(token.value, 0));
  if (value > 0) {
    addSun(state, value);
    state.stats.sunCollected += value;
  }
  return value;
}

/** Drop a sun token without collecting it (it expired). */
export function removeSunToken(state, tokenId) {
  if (!state) return null;
  const index = state.sunTokens.findIndex((token) => token.id === tokenId);
  if (index === -1) return null;
  return state.sunTokens.splice(index, 1)[0];
}

/* ------------------------------------------------------------------------- */
/* Zombies                                                                   */
/* ------------------------------------------------------------------------- */

/**
 * Spawn a zombie in a lane.
 *
 * @param {object} state
 * @param {object} definition zombie type ({type, health, speed, damage, biteInterval})
 * @param {number} row lane index
 * @param {number} [x] world x (defaults to just off the right edge)
 */
export function spawnZombie(state, definition, row, x) {
  if (!state) return null;
  const zombieType = getSeedType(definition) || 'basic';
  const lane = Number.isInteger(row) ? Math.min(Math.max(row, 0), state.rows - 1) : 0;
  const spawnX = asNumber(x, ZOMBIE_START_X);
  const requestedHealth =
    definition && typeof definition === 'object'
      ? definition.health ?? definition.maxHealth
      : undefined;
  const maxHealth = Math.max(1, asNumber(requestedHealth, DEFAULT_ZOMBIE_HEALTH));
  const laneCenter = cellCenter(lane, 0, state.layout || LAYOUT);

  const zombie = {
    id: nextEntityId(state),
    type: zombieType,
    row: lane,
    x: spawnX,
    y: laneCenter.y,
    health: maxHealth,
    maxHealth,
    speed: Math.max(0, asNumber(definition && definition.speed, DEFAULT_ZOMBIE_SPEED)),
    damage: Math.max(0, asNumber(definition && definition.damage, DEFAULT_ZOMBIE_DAMAGE)),
    biteInterval: Math.max(
      0.05,
      asNumber(definition && definition.biteInterval, DEFAULT_ZOMBIE_BITE_INTERVAL),
    ),
    biteTimer: 0,
    eating: false,
    definition: definition && typeof definition === 'object' ? definition : null,
  };

  state.zombies.push(zombie);
  state.stats.zombiesSpawned += 1;
  return zombie;
}

export function getZombieById(state, id) {
  if (!state) return null;
  return state.zombies.find((zombie) => zombie.id === id) || null;
}

export function getZombiesInRow(state, row) {
  if (!state) return [];
  return state.zombies.filter((zombie) => zombie.row === row);
}

/** Apply damage; returns whether the zombie died and the zombie itself. */
export function damageZombie(state, zombieId, amount) {
  const zombie = getZombieById(state, zombieId);
  if (!zombie) return { killed: false, zombie: null };
  zombie.health -= Math.max(0, asNumber(amount, 0));
  if (zombie.health <= 0) {
    removeZombie(state, zombieId, { killed: true });
    return { killed: true, zombie };
  }
  return { killed: false, zombie };
}

/** Remove a zombie. Pass `{ killed: true }` when it died from damage. */
export function removeZombie(state, zombieId, options = {}) {
  if (!state) return null;
  const index = state.zombies.findIndex((zombie) => zombie.id === zombieId);
  if (index === -1) return null;
  const [zombie] = state.zombies.splice(index, 1);
  if (options && options.killed) state.stats.zombiesKilled += 1;
  return zombie;
}

/** True when at least one zombie crossed the house wall. */
export function hasZombieReachedHouse(state) {
  if (!state) return false;
  return state.zombies.some((zombie) => zombie.x <= HOUSE_LINE_X);
}

/**
 * Evaluate the lose condition for the current frame. Winning is decided by the
 * level module once every wave is cleared ({@link markWon}).
 */
export function updateGameStatus(state) {
  if (!state) return null;
  if (isGameOver(state)) return state.status;
  if (hasZombieReachedHouse(state)) return markLost(state, 'zombie_reached_house');
  return state.status;
}

/* ------------------------------------------------------------------------- */
/* Seed bank selection and timers                                            */
/* ------------------------------------------------------------------------- */

export function selectSeed(state, seedType) {
  if (!state) return null;
  state.selectedSeed = getSeedType(seedType);
  return state.selectedSeed;
}

export function clearSelectedSeed(state) {
  if (!state) return null;
  state.selectedSeed = null;
  return null;
}

/** Advance the level clock and every seed-packet recharge. */
export function tickTimers(state, dt) {
  if (!state) return state;
  const step = asNumber(dt, 0);
  if (step <= 0) return state;
  state.elapsed += step;
  Object.keys(state.seedCooldowns).forEach((seedType) => {
    const remaining = asNumber(state.seedCooldowns[seedType], 0) - step;
    if (remaining > 0) {
      state.seedCooldowns[seedType] = remaining;
    } else {
      delete state.seedCooldowns[seedType];
    }
  });
  return state;
}

/* ------------------------------------------------------------------------- */
/* Bundled API                                                               */
/* ------------------------------------------------------------------------- */

const GameState = {
  GRID_ROWS,
  GRID_COLS,
  LAYOUT,
  BOARD_WIDTH,
  BOARD_HEIGHT,
  HOUSE_LINE_X,
  ZOMBIE_START_X,
  GAME_STATUS,
  STARTING_SUN,
  SUN_VALUE,
  SUN_LIFETIME,
  DEFAULT_PLANT_HEALTH,
  DEFAULT_ZOMBIE_HEALTH,
  DEFAULT_ZOMBIE_SPEED,
  DEFAULT_ZOMBIE_DAMAGE,
  DEFAULT_ZOMBIE_BITE_INTERVAL,
  createGameState,
  createInitialState,
  resetGameState,
  nextEntityId,
  isPlaying,
  isGameOver,
  setStatus,
  markWon,
  markLost,
  addSun,
  canAfford,
  spendSun,
  isInsideGrid,
  cellKey,
  cellCenter,
  pointToCell,
  getSeedType,
  getSeedRecharge,
  getPlantAt,
  getPlantById,
  canPlacePlant,
  placePlant,
  removePlant,
  addSunToken,
  getSunTokenById,
  collectSunToken,
  removeSunToken,
  spawnZombie,
  getZombieById,
  getZombiesInRow,
  damageZombie,
  removeZombie,
  hasZombieReachedHouse,
  updateGameStatus,
  selectSeed,
  clearSelectedSeed,
  tickTimers,
};

export default GameState;
