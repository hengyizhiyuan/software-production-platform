/**
 * zombies.js - Zombie capability for the Plants vs. Zombies style web game.
 *
 * Admitted PWU scope: this file only. The module is dependency free so that
 * src/game/level.js, src/game/plants.js, src/render/renderer.js and src/main.js
 * can wire it without this file importing (or redefining) their behaviour.
 *
 * The file loads either as a classic browser script
 * (window.PvZ.Zombies / window.Zombies) or through CommonJS
 * (module.exports) for Node based tests. No build step is required.
 *
 * Public API
 *   ZOMBIE_TYPES                     - stat table for the supported zombie kinds
 *   zombieTypeStats(type)            - resolved stats (unknown types fall back to basic)
 *   createZombie(options)            - build a single zombie record
 *   createZombieSystem(options)      - build a lane/wave simulation object
 *   createPlantFinder(getPlants, o)  - generic "is a plant in biting range?" finder
 *   defaultDamagePlant(plant, amount)
 *   defaultIsAlive(plant)
 *
 * system methods (createZombieSystem)
 *   spawn({type, lane, x?, speed?, eatDps?})  -> zombie
 *   spawnWave([{type, lane, x?}, ...])        -> zombie[]
 *   update(dtSeconds)                         -> event[]
 *        events: {type: 'house-reached', zombie} | {type: 'killed', zombie}
 *   damage(zombieOrId, amount)                -> zombie|null
 *   getZombies()                              -> zombie[]  (copy of the live list)
 *   getZombiesInLane(lane)                    -> zombie[]
 *   getZombieById(id)                         -> zombie|null
 *   getZombieCount()                          -> number
 *   isCleared()                               -> boolean
 *   hasBreachedHouse()                        -> boolean
 *   getStatus()                               -> summary object
 *   reset()                                   -> void
 *
 * Coordinate convention: `x` is the zombie's horizontal pixel position measured
 * from the left edge of the lawn. Zombies spawn at `spawnX` (right side) and
 * walk left towards `houseX`. When a zombie's x reaches houseX the lane has been
 * breached: the system emits a 'house-reached' event, records the breach and
 * removes the zombie. `level.js` owns the resulting lose state.
 *
 * Plant coupling: the system never mutates plant objects it did not create.
 * It asks the caller through `findTarget(zombie)` and reports bites through
 * `damageTarget(plant, amount)` / `isTargetAlive(plant)`, all injectable.
 */
(function (root, factory) {
  'use strict';

  var api = factory();

  if (typeof module === 'object' && module !== null && module.exports) {
    module.exports = api;
  }

  if (root) {
    root.PvZ = root.PvZ || {};
    root.PvZ.Zombies = api;
    if (!root.Zombies) {
      root.Zombies = api;
    }
  }
})(typeof globalThis !== 'undefined' ? globalThis : (typeof window !== 'undefined' ? window : this), function () {
  'use strict';

  /**
   * Stat table. `health` is the total hit points including the head armour, and
   * `armor` is the part of that total provided by the cone / bucket. The values
   * follow the original game closely enough for a faithful single level:
   * a normal zombie dies to five peas, a conehead to fourteen, a buckethead to
   * thirty four, and every walker eats roughly 100 hp of plant per second.
   */
  var ZOMBIE_TYPES = {
    basic: {
      key: 'basic',
      name: 'Zombie',
      health: 200,
      armor: 0,
      speed: 17,
      eatDps: 100,
      accessory: null
    },
    flag: {
      key: 'flag',
      name: 'Flag Zombie',
      health: 200,
      armor: 0,
      speed: 17,
      eatDps: 100,
      accessory: 'flag'
    },
    conehead: {
      key: 'conehead',
      name: 'Conehead Zombie',
      health: 570,
      armor: 370,
      speed: 17,
      eatDps: 100,
      accessory: 'cone'
    },
    buckethead: {
      key: 'buckethead',
      name: 'Buckethead Zombie',
      health: 1370,
      armor: 1100,
      speed: 17,
      eatDps: 100,
      accessory: 'bucket'
    }
  };

  /** Tolerant aliases so neighbouring modules can name the kinds naturally. */
  var ZOMBIE_TYPE_ALIASES = {
    normal: 'basic',
    basiczombie: 'basic',
    zombie: 'basic',
    walker: 'basic',
    flagzombie: 'flag',
    cone: 'conehead',
    conezombie: 'conehead',
    coneheadzombie: 'conehead',
    bucket: 'buckethead',
    bucketzombie: 'buckethead',
    bucketheadzombie: 'buckethead'
  };

  var DEFAULTS = {
    laneCount: 5,
    spawnX: 900,
    houseX: 40,
    maxStep: 0.25
  };

  function normaliseTypeName(type) {
    if (type === null || type === undefined || type === '') {
      return 'basic';
    }
    var key = String(type).toLowerCase().replace(/[\s_-]+/g, '');
    if (Object.prototype.hasOwnProperty.call(ZOMBIE_TYPES, key)) {
      return key;
    }
    if (Object.prototype.hasOwnProperty.call(ZOMBIE_TYPE_ALIASES, key)) {
      return ZOMBIE_TYPE_ALIASES[key];
    }
    return 'basic';
  }

  function zombieTypeStats(type) {
    return ZOMBIE_TYPES[normaliseTypeName(type)];
  }

  function normaliseLane(lane, laneCount) {
    var value = Number(lane);
    if (!isFinite(value)) {
      value = 0;
    }
    value = Math.floor(value);
    if (value < 0) {
      value = 0;
    }
    if (value > laneCount - 1) {
      value = laneCount - 1;
    }
    return value;
  }

  function normaliseNumber(value, fallback) {
    var parsed = Number(value);
    return isFinite(parsed) ? parsed : fallback;
  }

  function defaultIsAlive(plant) {
    if (!plant) {
      return false;
    }
    if (plant.removed || plant.dead) {
      return false;
    }
    if (typeof plant.health === 'number') {
      return plant.health > 0;
    }
    if (typeof plant.hp === 'number') {
      return plant.hp > 0;
    }
    return true;
  }

  function defaultDamagePlant(plant, amount) {
    if (!plant) {
      return;
    }
    var value = normaliseNumber(amount, 0);
    if (value <= 0) {
      return;
    }
    if (typeof plant.health === 'number') {
      plant.health = Math.max(0, plant.health - value);
      return;
    }
    if (typeof plant.hp === 'number') {
      plant.hp = Math.max(0, plant.hp - value);
    }
  }

  function readPlantX(plant) {
    if (!plant) {
      return null;
    }
    if (typeof plant.x === 'number') {
      return plant.x;
    }
    if (typeof plant.px === 'number') {
      return plant.px;
    }
    if (plant.cell && typeof plant.cell.x === 'number') {
      return plant.cell.x;
    }
    return null;
  }

  function readPlantLane(plant) {
    if (!plant) {
      return null;
    }
    if (typeof plant.lane === 'number') {
      return plant.lane;
    }
    if (typeof plant.row === 'number') {
      return plant.row;
    }
    if (plant.cell) {
      if (typeof plant.cell.lane === 'number') {
        return plant.cell.lane;
      }
      if (typeof plant.cell.row === 'number') {
        return plant.cell.row;
      }
    }
    return null;
  }

  /**
   * Build a findTarget(zombie) function over any plant collection. A plant is a
   * bite target when it lives in the zombie's lane and sits within `reach`
   * pixels in front of the walking zombie (the zombie walks right to left, so
   * "in front" means a smaller or equal x).
   */
  function createPlantFinder(getPlants, options) {
    options = options || {};
    var reach = normaliseNumber(options.reach, 36);
    var getX = options.getX || readPlantX;
    var getLane = options.getLane || readPlantLane;
    var isAlive = options.isAlive || defaultIsAlive;
    var behindTolerance = reach * 0.5;

    return function findTarget(zombie) {
      if (!zombie) {
        return null;
      }
      var plants = typeof getPlants === 'function' ? getPlants() : getPlants;
      if (!plants || typeof plants.length !== 'number') {
        return null;
      }
      var best = null;
      var bestDistance = Infinity;
      for (var index = 0; index < plants.length; index += 1) {
        var plant = plants[index];
        if (!plant || !isAlive(plant)) {
          continue;
        }
        if (getLane(plant) !== zombie.lane) {
          continue;
        }
        var x = getX(plant);
        if (typeof x !== 'number') {
          continue;
        }
        var dx = zombie.x - x;
        if (dx > reach || dx < -behindTolerance) {
          continue;
        }
        var distance = Math.abs(dx);
        if (distance < bestDistance) {
          best = plant;
          bestDistance = distance;
        }
      }
      return best;
    };
  }

  var nextZombieSequence = 0;

  /**
   * Create one zombie record. Exposed separately so tests (and level waves) can
   * build a record without a simulation object.
   */
  function createZombie(options) {
    options = options || {};
    var type = normaliseTypeName(options.type);
    var stats = ZOMBIE_TYPES[type];
    var spawnX = normaliseNumber(options.spawnX, DEFAULTS.spawnX);
    nextZombieSequence += 1;

    return {
      id: typeof options.id === 'string' && options.id ? options.id : 'zombie-' + nextZombieSequence,
      type: type,
      name: stats.name,
      accessory: stats.accessory,
      lane: normaliseLane(options.lane, normaliseNumber(options.laneCount, DEFAULTS.laneCount)),
      x: normaliseNumber(options.x, spawnX),
      health: stats.health,
      maxHealth: stats.health,
      armor: stats.armor,
      maxArmor: stats.armor,
      speed: normaliseNumber(options.speed, stats.speed),
      eatDps: normaliseNumber(options.eatDps, stats.eatDps),
      eating: false,
      dead: false,
      reachedHouse: false,
      walkTime: 0,
      eatTime: 0
    };
  }

  function applyDamage(zombie, amount) {
    if (!zombie || zombie.reachedHouse) {
      return zombie;
    }
    var value = Number(amount);
    if (!isFinite(value) || value <= 0) {
      return zombie;
    }
    if (zombie.armor > 0) {
      zombie.armor = Math.max(0, zombie.armor - value);
    }
    zombie.health = Math.max(0, zombie.health - value);
    if (zombie.health <= 0) {
      zombie.dead = true;
    }
    return zombie;
  }

  function createZombieSystem(options) {
    options = options || {};

    var laneCount = Math.max(1, Math.floor(normaliseNumber(options.laneCount, DEFAULTS.laneCount)));
    var spawnX = normaliseNumber(options.spawnX, DEFAULTS.spawnX);
    var houseX = normaliseNumber(options.houseX, DEFAULTS.houseX);
    var maxStep = Math.max(0.001, normaliseNumber(options.maxStep, DEFAULTS.maxStep));

    var findTarget = typeof options.findTarget === 'function' ? options.findTarget : null;
    var damageTarget = typeof options.damageTarget === 'function' ? options.damageTarget : defaultDamagePlant;
    var isTargetAlive = typeof options.isTargetAlive === 'function' ? options.isTargetAlive : defaultIsAlive;
    var onHouseReached = typeof options.onHouseReached === 'function' ? options.onHouseReached : null;
    var onZombieKilled = typeof options.onZombieKilled === 'function' ? options.onZombieKilled : null;
    var onSpawn = typeof options.onSpawn === 'function' ? options.onSpawn : null;

    var zombies = [];
    var totalSpawned = 0;
    var totalKilled = 0;
    var breached = false;

    function spawn(spawnOptions) {
      spawnOptions = spawnOptions || {};
      var zombie = createZombie({
        id: spawnOptions.id,
        type: spawnOptions.type,
        lane: spawnOptions.lane,
        laneCount: laneCount,
        x: spawnOptions.x,
        spawnX: spawnX,
        speed: spawnOptions.speed,
        eatDps: spawnOptions.eatDps
      });
      zombies.push(zombie);
      totalSpawned += 1;
      if (onSpawn) {
        onSpawn(zombie);
      }
      return zombie;
    }

    function spawnWave(entries) {
      var spawned = [];
      if (!entries || typeof entries.length !== 'number') {
        return spawned;
      }
      for (var index = 0; index < entries.length; index += 1) {
        spawned.push(spawn(entries[index]));
      }
      return spawned;
    }

    function findById(zombieOrId) {
      if (!zombieOrId) {
        return null;
      }
      if (typeof zombieOrId === 'string') {
        for (var index = 0; index < zombies.length; index += 1) {
          if (zombies[index].id === zombieOrId) {
            return zombies[index];
          }
        }
        return null;
      }
      return zombieOrId;
    }

    function damage(zombieOrId, amount) {
      var zombie = findById(zombieOrId);
      if (!zombie) {
        return null;
      }
      return applyDamage(zombie, amount);
    }

    /**
     * Advance the simulation. `dt` is in seconds. Returns the events produced by
     * this step so level.js can react to a breached lane or a cleared lane
     * without polling every zombie object.
     */
    function update(dt) {
      var events = [];
      var step = Number(dt);
      if (!isFinite(step) || step <= 0) {
        return events;
      }
      if (step > maxStep) {
        step = maxStep;
      }

      var survivors = [];

      for (var index = 0; index < zombies.length; index += 1) {
        var zombie = zombies[index];

        if (zombie.health <= 0 || zombie.dead) {
          zombie.dead = true;
          totalKilled += 1;
          events.push({ type: 'killed', zombie: zombie, lane: zombie.lane });
          if (onZombieKilled) {
            onZombieKilled(zombie);
          }
          continue;
        }

        var target = null;
        if (findTarget) {
          target = findTarget(zombie);
          if (target && !isTargetAlive(target)) {
            target = null;
          }
        }

        if (target) {
          zombie.eating = true;
          zombie.eatTime += step;
          zombie.walkTime = 0;
          damageTarget(target, zombie.eatDps * step);
          survivors.push(zombie);
          continue;
        }

        zombie.eating = false;
        zombie.eatTime = 0;
        zombie.walkTime += step;
        zombie.x -= zombie.speed * step;

        if (zombie.x <= houseX) {
          zombie.x = houseX;
          zombie.reachedHouse = true;
          breached = true;
          events.push({ type: 'house-reached', zombie: zombie, lane: zombie.lane });
          if (onHouseReached) {
            onHouseReached(zombie);
          }
          continue;
        }

        survivors.push(zombie);
      }

      zombies = survivors;
      return events;
    }

    function getZombies() {
      return zombies.slice();
    }

    function getZombiesInLane(lane) {
      var wanted = Math.floor(normaliseNumber(lane, -1));
      var found = [];
      for (var index = 0; index < zombies.length; index += 1) {
        if (zombies[index].lane === wanted) {
          found.push(zombies[index]);
        }
      }
      return found;
    }

    function getZombieById(id) {
      var zombie = findById(id);
      return zombie && typeof zombie === 'object' ? zombie : null;
    }

    function getZombieCount() {
      return zombies.length;
    }

    function isCleared() {
      return zombies.length === 0;
    }

    function hasBreachedHouse() {
      return breached;
    }

    function getStatus() {
      return {
        laneCount: laneCount,
        spawnX: spawnX,
        houseX: houseX,
        alive: zombies.length,
        totalSpawned: totalSpawned,
        totalKilled: totalKilled,
        breached: breached,
        cleared: zombies.length === 0
      };
    }

    function reset() {
      zombies = [];
      totalSpawned = 0;
      totalKilled = 0;
      breached = false;
    }

    return {
      laneCount: laneCount,
      spawnX: spawnX,
      houseX: houseX,
      spawn: spawn,
      spawnWave: spawnWave,
      update: update,
      damage: damage,
      getZombies: getZombies,
      getZombiesInLane: getZombiesInLane,
      getZombieById: getZombieById,
      getZombieCount: getZombieCount,
      isCleared: isCleared,
      hasBreachedHouse: hasBreachedHouse,
      getStatus: getStatus,
      reset: reset
    };
  }

  return {
    ZOMBIE_TYPES: ZOMBIE_TYPES,
    DEFAULTS: DEFAULTS,
    zombieTypeStats: zombieTypeStats,
    createZombie: createZombie,
    createZombieSystem: createZombieSystem,
    createPlantFinder: createPlantFinder,
    defaultIsAlive: defaultIsAlive,
    defaultDamagePlant: defaultDamagePlant
  };
});
