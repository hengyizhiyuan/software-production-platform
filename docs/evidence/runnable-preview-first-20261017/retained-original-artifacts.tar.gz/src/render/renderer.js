/**
 * src/render/renderer.js
 *
 * Canvas 2D renderer for the single-level Plants vs. Zombies style core loop
 * (sun collection, plant placement, zombie waves, win/lose determination).
 *
 * Responsibilities
 * ----------------
 * - Draw one full frame from a plain state snapshot: lawn grid, house wall the
 *   zombies advance toward, plants, projectiles, zombies, falling sun, the seed
 *   bank (sun counter + seed packets with cost/recharge state), wave progress
 *   and the win/lose overlay.
 * - Provide pure layout math (grid <-> pixel) that the input layer can reuse.
 * - Provide hit testing for the seed bank cards.
 *
 * Non-responsibilities
 * --------------------
 * - No game logic, no timers, no input handling, no window/DOM ownership beyond
 *   the canvas it is handed. This module never imports game modules: it consumes
 *   a state snapshot so that the state/level/sun/plants/zombies modules stay
 *   independent of presentation.
 *
 * Assets
 * ------
 * All artwork is generated procedurally with Canvas 2D primitives, so the
 * project ships original assets and has no external image dependency.
 *
 * Integration contract
 * --------------------
 * Accepted snapshot keys and the tolerated aliases used while the sibling
 * modules land are listed in RENDERER_STATE_CONTRACT below. Entity horizontal
 * placement accepts either an absolute pixel `x` or a fractional `col` in
 * column units (0 = left edge of the first lawn column); pixels take
 * precedence when both are present.
 */

export const RENDERER_VERSION = '1.0.0';

export const DEFAULT_GRID = Object.freeze({ rows: 5, cols: 9 });

export const DEFAULT_LAYOUT_OPTIONS = Object.freeze({
  width: 1000,
  height: 620,
  rows: 5,
  cols: 9,
  topBarHeight: 92,
  bottomBarHeight: 34,
  leftHouseWidth: 78,
  rightMargin: 48,
});

export const RENDERER_STATE_CONTRACT = Object.freeze({
  sun: ['sun', 'sunCount', 'sunlight'],
  plants: ['plants'],
  zombies: ['zombies'],
  projectiles: ['projectiles', 'bullets', 'peas', 'shots'],
  suns: ['suns', 'sunTokens'],
  seedPackets: ['seedPackets', 'seedBank', 'seeds', 'cards'],
  seedTypes: ['seedTypes', 'availablePlants', 'plantTypes'],
  selectedPlantType: ['selectedPlantType', 'selected', 'carriedPlant'],
  status: ['status', 'gameStatus', 'phase'],
  wave: ['wave', 'waveIndex', 'waveTotal', 'waveProgress'],
});

export const DEFAULT_LABELS = Object.freeze({
  won: 'LEVEL COMPLETE',
  lost: 'GAME OVER',
  wave: 'Wave',
  hint: '',
  restartHint: '',
});

export const PROJECTILE_COLORS = Object.freeze({
  pea: '#8bd44a',
  snowpea: '#bff0ff',
  snow_pea: '#bff0ff',
  snow: '#bff0ff',
  star: '#ffe066',
  fire: '#ff9a3c',
});

/* ------------------------------------------------------------------ *
 * small helpers
 * ------------------------------------------------------------------ */

function num(value, fallback) {
  if (value === null || value === undefined || value === '' || typeof value === 'boolean') {
    return fallback === undefined ? 0 : fallback;
  }
  const n = Number(value);
  return Number.isFinite(n) ? n : (fallback === undefined ? 0 : fallback);
}

function arr(value) {
  return Array.isArray(value) ? value : [];
}

function clamp(value, min, max) {
  const v = num(value, min);
  if (v < min) return min;
  if (v > max) return max;
  return v;
}

function pick(source, keys, fallback) {
  const missing = fallback === undefined ? null : fallback;
  if (!source || typeof source !== 'object') return missing;
  for (let i = 0; i < keys.length; i += 1) {
    const value = source[keys[i]];
    if (value !== undefined && value !== null) return value;
  }
  return missing;
}

function nowMs() {
  if (typeof performance !== 'undefined' && performance && typeof performance.now === 'function') {
    return performance.now();
  }
  return Date.now();
}

function roundRectPath(ctx, x, y, w, h, r) {
  const radius = Math.max(0, Math.min(num(r, 0), Math.abs(w) / 2, Math.abs(h) / 2));
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + h - radius);
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
  ctx.lineTo(x + radius, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

function fillRoundRect(ctx, x, y, w, h, r, fillStyle) {
  ctx.beginPath();
  roundRectPath(ctx, x, y, w, h, r);
  ctx.fillStyle = fillStyle;
  ctx.fill();
}

function strokeRoundRect(ctx, x, y, w, h, r, strokeStyle, lineWidth) {
  ctx.beginPath();
  roundRectPath(ctx, x, y, w, h, r);
  ctx.strokeStyle = strokeStyle;
  ctx.lineWidth = num(lineWidth, 1);
  ctx.stroke();
}

function healthRatio(entity) {
  const hp = num(pick(entity, ['hp', 'health', 'hits'], null), NaN);
  const max = num(pick(entity, ['maxHp', 'maxHealth', 'maxHits'], null), NaN);
  if (!Number.isFinite(hp) || !Number.isFinite(max) || max <= 0) return null;
  if (hp >= max) return null;
  return clamp(hp / max, 0, 1);
}

/* ------------------------------------------------------------------ *
 * layout math
 * ------------------------------------------------------------------ */

export function createLayout(options) {
  const o = Object.assign({}, DEFAULT_LAYOUT_OPTIONS, options || {});
  const cols = Math.max(1, Math.floor(num(o.cols, DEFAULT_GRID.cols)));
  const rows = Math.max(1, Math.floor(num(o.rows, DEFAULT_GRID.rows)));
  const width = Math.max(320, Math.floor(num(o.width, DEFAULT_LAYOUT_OPTIONS.width)));
  const height = Math.max(260, Math.floor(num(o.height, DEFAULT_LAYOUT_OPTIONS.height)));
  const topBarHeight = clamp(
    Math.floor(num(o.topBarHeight, DEFAULT_LAYOUT_OPTIONS.topBarHeight)),
    0,
    Math.max(0, height - 80),
  );
  const bottomBarHeight = clamp(
    Math.floor(num(o.bottomBarHeight, DEFAULT_LAYOUT_OPTIONS.bottomBarHeight)),
    0,
    Math.max(0, height - topBarHeight - 80),
  );
  const leftHouseWidth = clamp(
    Math.floor(num(o.leftHouseWidth, DEFAULT_LAYOUT_OPTIONS.leftHouseWidth)),
    0,
    Math.max(0, width - 120),
  );
  const rightMargin = clamp(
    Math.floor(num(o.rightMargin, DEFAULT_LAYOUT_OPTIONS.rightMargin)),
    0,
    Math.max(0, width - leftHouseWidth - 120),
  );
  const gridX = leftHouseWidth;
  const gridY = topBarHeight;
  const gridWidth = Math.max(1, width - leftHouseWidth - rightMargin);
  const gridHeight = Math.max(1, height - topBarHeight - bottomBarHeight);
  const cellWidth = gridWidth / cols;
  const cellHeight = gridHeight / rows;
  return {
    width,
    height,
    rows,
    cols,
    topBarHeight,
    bottomBarHeight,
    leftHouseWidth,
    rightMargin,
    gridX,
    gridY,
    gridWidth,
    gridHeight,
    cellWidth,
    cellHeight,
    houseLineX: gridX,
  };
}

/** Center point of a lawn cell in canvas pixels. */
export function gridToPixel(layout, row, col) {
  const r = clamp(Math.floor(num(row, 0)), 0, layout.rows - 1);
  const c = clamp(Math.floor(num(col, 0)), 0, layout.cols - 1);
  return {
    x: layout.gridX + (c + 0.5) * layout.cellWidth,
    y: layout.gridY + (r + 0.5) * layout.cellHeight,
    row: r,
    col: c,
  };
}

/** Inverse of gridToPixel; `inside` is false outside the lawn. */
export function pixelToGrid(layout, x, y) {
  const col = Math.floor((num(x, 0) - layout.gridX) / layout.cellWidth);
  const row = Math.floor((num(y, 0) - layout.gridY) / layout.cellHeight);
  return {
    row,
    col,
    inside: row >= 0 && row < layout.rows && col >= 0 && col < layout.cols,
  };
}

function axis(entity, pixelKeys, unitKeys, origin, unitSize, fallback) {
  const px = pick(entity, pixelKeys, null);
  if (px !== null) return num(px, fallback);
  const unit = pick(entity, unitKeys, null);
  if (unit !== null) return origin + num(unit, 0) * unitSize;
  return fallback;
}

/**
 * Resolve an entity (plant, zombie, projectile, sun) to a canvas pixel point.
 * Absolute pixel keys win; otherwise fractional grid units are converted.
 */
export function entityPixel(layout, entity, fallbackRow) {
  const e = entity && typeof entity === 'object' ? entity : {};
  const row = clamp(
    Math.floor(num(pick(e, ['row', 'lane'], fallbackRow === undefined ? 0 : fallbackRow), 0)),
    0,
    layout.rows - 1,
  );
  const col = clamp(num(pick(e, ['col', 'column'], 0), 0), 0, layout.cols);
  const x = axis(e, ['x', 'px', 'screenX'], ['col', 'column'], layout.gridX, layout.cellWidth, layout.gridX + col * layout.cellWidth);
  const y = axis(
    e,
    ['y', 'py', 'screenY'],
    ['row', 'lane'],
    layout.gridY,
    layout.cellHeight,
    layout.gridY + (row + 0.5) * layout.cellHeight,
  );
  return { x, y, row, col };
}

/* ------------------------------------------------------------------ *
 * seed bank geometry + packet normalization
 * ------------------------------------------------------------------ */

export function seedBankGeometry(layout, packetCount) {
  const count = Math.max(0, Math.floor(num(packetCount, 0)));
  const padY = Math.max(6, Math.round(layout.topBarHeight * 0.1));
  const cardHeight = Math.max(40, layout.topBarHeight - padY * 2);
  const sunWidth = clamp(Math.round(layout.width * 0.12), 62, 110);
  const sunBox = { x: 10, y: padY, width: sunWidth, height: cardHeight };
  const gap = 8;
  const startX = sunBox.x + sunBox.width + 16;
  const available = Math.max(60, layout.width - startX - 12);
  let cardWidth = 58;
  if (count > 0) {
    const fit = (available - gap * (count - 1)) / count;
    cardWidth = clamp(Math.min(58, fit), 28, 58);
  }
  const cards = [];
  for (let i = 0; i < count; i += 1) {
    cards.push({
      index: i,
      x: startX + i * (cardWidth + gap),
      y: padY,
      width: cardWidth,
      height: cardHeight,
    });
  }
  return { sunBox, cards, cardWidth, cardHeight, gap };
}

export function sunOf(state) {
  return num(pick(state, ['sun', 'sunCount', 'sunlight'], 0), 0);
}

/**
 * Normalize the seed bank into a drawable list. Cost, recharge and availability
 * are read from the packet when provided and otherwise derived from the current
 * sun amount and the recharge countdown.
 */
export function normalizeSeedPackets(state, sunAmount) {
  const s = state && typeof state === 'object' ? state : {};
  const sun = num(sunAmount === undefined || sunAmount === null ? sunOf(s) : sunAmount, 0);
  const raw = pick(s, ['seedPackets', 'seedBank', 'seeds', 'cards'], null);
  const list = Array.isArray(raw)
    ? raw
    : arr(pick(s, ['seedTypes', 'availablePlants', 'plantTypes'], null));
  const selectedType = pick(s, ['selectedPlantType', 'selected', 'carriedPlant'], null);

  return list.map(function mapPacket(entry, index) {
    const item = typeof entry === 'string' ? { type: entry } : (entry && typeof entry === 'object' ? entry : {});
    const type = String(pick(item, ['type', 'id', 'key', 'name'], 'plant'));
    const cost = num(pick(item, ['cost', 'price', 'sunCost'], 0), 0);
    const cooldownTotal = num(pick(item, ['cooldown', 'recharge', 'cooldownTotal', 'rechargeTotal'], 0), 0);
    const cooldownRemaining = num(
      pick(item, ['cooldownRemaining', 'remaining', 'rechargeRemaining', 'cooldownLeft'], 0),
      0,
    );
    const explicitReady = pick(item, ['ready', 'available'], null);
    const ready = explicitReady === null ? cooldownRemaining <= 0 : explicitReady !== false;
    const explicitAffordable = pick(item, ['affordable', 'canAfford'], null);
    const affordable = explicitAffordable === null ? sun >= cost : explicitAffordable !== false;
    const explicitSelected = pick(item, ['selected'], null);
    const selected = explicitSelected === null
      ? (selectedType !== null && String(selectedType) === type)
      : explicitSelected === true;
    return {
      index,
      type,
      cost,
      cooldownTotal,
      cooldownRemaining,
      cooldownRatio: cooldownTotal > 0 ? clamp(cooldownRemaining / cooldownTotal, 0, 1) : 0,
      ready,
      affordable,
      disabled: pick(item, ['disabled'], false) === true || !ready || !affordable,
      selected,
    };
  });
}

/* ------------------------------------------------------------------ *
 * drawable registries (extensible by other modules)
 * ------------------------------------------------------------------ */

export const PLANT_DRAWERS = new Map();
export const ZOMBIE_DRAWERS = new Map();

export function registerPlantType(type, drawFn) {
  if (typeof drawFn !== 'function') throw new TypeError('registerPlantType(type, drawFn) needs a draw function');
  PLANT_DRAWERS.set(String(type), drawFn);
  return PLANT_DRAWERS.get(String(type));
}

export function registerZombieType(type, drawFn) {
  if (typeof drawFn !== 'function') throw new TypeError('registerZombieType(type, drawFn) needs a draw function');
  ZOMBIE_DRAWERS.set(String(type), drawFn);
  return ZOMBIE_DRAWERS.get(String(type));
}

export function getPlantTypes() {
  return Array.from(PLANT_DRAWERS.keys());
}

export function getZombieTypes() {
  return Array.from(ZOMBIE_DRAWERS.keys());
}

/* ------------------------------------------------------------------ *
 * plant artwork (nominal 80x100 cell space, origin at cell center)
 * ------------------------------------------------------------------ */

function drawPlantStem(ctx, color, topY) {
  ctx.strokeStyle = color;
  ctx.lineWidth = 7;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 34);
  ctx.quadraticCurveTo(-6, 8, 0, num(topY, 0));
  ctx.stroke();
}

function drawPlantLeaves(ctx, color, y) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.ellipse(-15, num(y, 26), 13, 6, -0.45, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(15, num(y, 26), 13, 6, 0.45, 0, Math.PI * 2);
  ctx.fill();
}

function drawPlantSunflower(ctx, plant, time) {
  const bob = Math.sin(num(time, 0) / 420 + 0.4) * 2;
  drawPlantStem(ctx, '#3f8f2d', 2);
  drawPlantLeaves(ctx, '#4aa63a', 26);
  ctx.save();
  ctx.translate(0, -6 + bob);
  ctx.fillStyle = '#ffd83b';
  for (let i = 0; i < 10; i += 1) {
    ctx.save();
    ctx.rotate((i / 10) * Math.PI * 2 + Math.sin(num(time, 0) / 900) * 0.1);
    ctx.beginPath();
    ctx.ellipse(0, -26, 8, 12, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  ctx.beginPath();
  ctx.arc(0, 0, 16, 0, Math.PI * 2);
  ctx.fillStyle = '#b5761f';
  ctx.fill();
  ctx.fillStyle = '#4a2f08';
  ctx.beginPath();
  ctx.arc(-6, -3, 2.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(6, -3, 2.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#4a2f08';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 3, 7, 0.15 * Math.PI, 0.85 * Math.PI);
  ctx.stroke();
  ctx.restore();
}

function makeShooterDrawer(colors) {
  const palette = colors || { head: '#57b83a', barrel: '#4aa32f', muzzle: '#2b6b1c' };
  return function drawShooter(ctx, plant, time) {
    const bob = Math.sin(num(time, 0) / 500 + 1.1) * 1.5;
    drawPlantStem(ctx, '#2f7d24', 4);
    drawPlantLeaves(ctx, '#3f9a30', 28);
    ctx.save();
    ctx.translate(0, -6 + bob);
    ctx.fillStyle = palette.head;
    ctx.beginPath();
    ctx.arc(-3, -6, 17, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = palette.barrel;
    ctx.beginPath();
    roundRectPath(ctx, -1, -14, 28, 16, 7);
    ctx.fill();
    ctx.fillStyle = palette.muzzle;
    ctx.beginPath();
    ctx.arc(26, -6, 6.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#12380b';
    ctx.beginPath();
    ctx.arc(-10, -12, 2.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };
}

const drawShooterBase = makeShooterDrawer({ head: '#57b83a', barrel: '#4aa32f', muzzle: '#2b6b1c' });
const drawSnowShooterBase = makeShooterDrawer({ head: '#7fd8ee', barrel: '#6cc7e4', muzzle: '#3f9cbb' });

function drawPlantPeashooter(ctx, plant, time) {
  drawShooterBase(ctx, plant, time);
}

function drawPlantSnowPea(ctx, plant, time) {
  drawSnowShooterBase(ctx, plant, time);
  ctx.save();
  ctx.fillStyle = 'rgba(220,250,255,0.75)';
  ctx.beginPath();
  ctx.arc(-3, -12, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawPlantRepeater(ctx, plant, time) {
  drawShooterBase(ctx, plant, time);
  ctx.save();
  ctx.fillStyle = '#3d8f2b';
  ctx.beginPath();
  roundRectPath(ctx, -8, -1, 26, 13, 6);
  ctx.fill();
  ctx.fillStyle = '#255e18';
  ctx.beginPath();
  ctx.arc(18, 5.5, 5.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawPlantWallnut(ctx, plant, time) {
  const ratio = healthRatio(plant);
  const wobble = Math.sin(num(time, 0) / 700) * 1.4;
  ctx.save();
  ctx.rotate((wobble * Math.PI) / 180);
  ctx.fillStyle = '#cf9440';
  ctx.beginPath();
  ctx.ellipse(0, 6, 25, 32, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#8c5a1d';
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.fillStyle = 'rgba(255,236,196,0.35)';
  ctx.beginPath();
  ctx.ellipse(-9, -6, 8, 13, -0.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#3a2408';
  ctx.beginPath();
  ctx.arc(-8, 2, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(8, 2, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#3a2408';
  ctx.lineWidth = 2.4;
  ctx.beginPath();
  ctx.arc(0, 12, 8, 0.15 * Math.PI, 0.85 * Math.PI);
  ctx.stroke();
  const damage = ratio === null ? 1 : ratio;
  if (damage < 0.66) {
    ctx.strokeStyle = '#6f4515';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(-18, -14);
    ctx.lineTo(-8, -2);
    ctx.lineTo(-16, 8);
    ctx.stroke();
  }
  if (damage < 0.34) {
    ctx.strokeStyle = '#5c370f';
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(18, -18);
    ctx.lineTo(6, -4);
    ctx.lineTo(18, 6);
    ctx.stroke();
  }
  ctx.restore();
}

function drawPlantCherryBomb(ctx, plant, time) {
  const pulse = 1 + Math.sin(num(time, 0) / 120) * 0.06;
  ctx.save();
  ctx.scale(pulse, pulse);
  ctx.strokeStyle = '#3f7d24';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(-10, -6);
  ctx.quadraticCurveTo(-6, -30, 4, -34);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(10, -4);
  ctx.quadraticCurveTo(8, -30, 4, -34);
  ctx.stroke();
  ctx.fillStyle = '#4aa63a';
  ctx.beginPath();
  ctx.ellipse(14, -34, 10, 5, 0.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#d8342f';
  ctx.beginPath();
  ctx.arc(-11, 10, 15, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(11, 12, 15, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = 'rgba(255,220,200,0.5)';
  ctx.beginPath();
  ctx.arc(-15, 4, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(7, 6, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawPlantPotatoMine(ctx, plant, time) {
  const armed = pick(plant, ['armed', 'ready'], true) !== false;
  const blink = 0.5 + 0.5 * Math.sin(num(time, 0) / 180);
  ctx.save();
  ctx.fillStyle = '#8b6a3f';
  ctx.beginPath();
  ctx.ellipse(0, 14, 26, 16, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#6d5230';
  ctx.beginPath();
  ctx.arc(-12, 10, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(10, 16, 3.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = armed
    ? 'rgba(255,90,70,' + (0.4 + 0.6 * blink).toFixed(3) + ')'
    : 'rgba(130,130,130,0.5)';
  ctx.beginPath();
  ctx.arc(0, -6, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawPlantFallback(ctx, plant, time) {
  const label = String(pick(plant, ['type', 'kind', 'id'], '?')).slice(0, 3).toUpperCase();
  ctx.save();
  ctx.fillStyle = '#6fbf4a';
  ctx.beginPath();
  ctx.ellipse(0, 6, 24, 28, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#3d8b2f';
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.fillStyle = '#173a10';
  ctx.font = 'bold 16px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(label, 0, 6);
  ctx.restore();
}

registerPlantType('sunflower', drawPlantSunflower);
registerPlantType('sun_flower', drawPlantSunflower);
registerPlantType('peashooter', drawPlantPeashooter);
registerPlantType('pea_shooter', drawPlantPeashooter);
registerPlantType('pea', drawPlantPeashooter);
registerPlantType('snowpea', drawPlantSnowPea);
registerPlantType('snow_pea', drawPlantSnowPea);
registerPlantType('snowpeashooter', drawPlantSnowPea);
registerPlantType('repeater', drawPlantRepeater);
registerPlantType('wallnut', drawPlantWallnut);
registerPlantType('wall_nut', drawPlantWallnut);
registerPlantType('cherrybomb', drawPlantCherryBomb);
registerPlantType('cherry_bomb', drawPlantCherryBomb);
registerPlantType('potatomine', drawPlantPotatoMine);
registerPlantType('potato_mine', drawPlantPotatoMine);

/* ------------------------------------------------------------------ *
 * zombie artwork (nominal space: feet at origin, body extends upward)
 * ------------------------------------------------------------------ */

const ZOMBIE_PALETTES = Object.freeze({
  basic: { skin: '#a9c08e', shirt: '#6c6f9c', trouser: '#3f4358', headgear: '#e08a2c' },
  conehead: { skin: '#a9c08e', shirt: '#7d6fa8', trouser: '#3f4358', headgear: '#e08a2c' },
  buckethead: { skin: '#9fb887', shirt: '#6b6b6b', trouser: '#3b3f4e', headgear: '#9aa2ad' },
  flag: { skin: '#a9c08e', shirt: '#8a6c4c', trouser: '#3f4358', headgear: '#c53030' },
  fallback: { skin: '#a9c08e', shirt: '#6c6f9c', trouser: '#3f4358', headgear: '#e08a2c' },
});

function drawZombieBase(ctx, zombie, time, palette) {
  const phase = num(pick(zombie, ['animPhase', 'phase', 'offset'], 0), 0);
  const step = Math.sin(num(time, 0) / 150 + phase);
  ctx.save();

  // legs
  ctx.fillStyle = palette.trouser;
  ctx.save();
  ctx.translate(-7, -30);
  ctx.rotate(step * 0.18);
  ctx.fillRect(-6, 0, 12, 32);
  ctx.restore();
  ctx.save();
  ctx.translate(7, -30);
  ctx.rotate(-step * 0.18);
  ctx.fillRect(-6, 0, 12, 32);
  ctx.restore();

  // torso
  ctx.fillStyle = palette.shirt;
  ctx.beginPath();
  roundRectPath(ctx, -17, -64, 34, 38, 9);
  ctx.fill();

  // tattered hem
  ctx.fillStyle = palette.trouser;
  ctx.beginPath();
  ctx.moveTo(-17, -28);
  ctx.lineTo(-9, -20);
  ctx.lineTo(-2, -28);
  ctx.lineTo(6, -19);
  ctx.lineTo(17, -28);
  ctx.lineTo(17, -24);
  ctx.lineTo(-17, -24);
  ctx.closePath();
  ctx.fill();

  // arms reaching toward the house
  ctx.strokeStyle = palette.skin;
  ctx.lineWidth = 8;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(-8, -56);
  ctx.lineTo(-34, -46 + step * 3);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-2, -52);
  ctx.lineTo(-28, -36 - step * 3);
  ctx.stroke();

  // head
  ctx.fillStyle = palette.skin;
  ctx.beginPath();
  ctx.arc(-10, -76, 14, 0, Math.PI * 2);
  ctx.fill();

  // mouth
  ctx.strokeStyle = '#5c2b2b';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-22, -70);
  ctx.lineTo(-10, -68);
  ctx.stroke();

  // eye
  ctx.fillStyle = '#f3f1dc';
  ctx.beginPath();
  ctx.arc(-16, -80, 4.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#111111';
  ctx.beginPath();
  ctx.arc(-17, -80, 2.1, 0, Math.PI * 2);
  ctx.fill();

  // hair tuft
  ctx.strokeStyle = '#2b2b2b';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-4, -88);
  ctx.lineTo(2, -94);
  ctx.stroke();

  ctx.restore();
}

function drawZombieBasic(ctx, zombie, time) {
  drawZombieBase(ctx, zombie, time, ZOMBIE_PALETTES.basic);
}

function drawZombieConehead(ctx, zombie, time) {
  const palette = ZOMBIE_PALETTES.conehead;
  drawZombieBase(ctx, zombie, time, palette);
  ctx.save();
  ctx.fillStyle = palette.headgear;
  ctx.beginPath();
  ctx.moveTo(-10, -110);
  ctx.lineTo(-24, -80);
  ctx.lineTo(4, -80);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = '#a35d14';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();
}

function drawZombieBuckethead(ctx, zombie, time) {
  const palette = ZOMBIE_PALETTES.buckethead;
  drawZombieBase(ctx, zombie, time, palette);
  ctx.save();
  fillRoundRect(ctx, -26, -100, 32, 30, 3, palette.headgear);
  ctx.fillStyle = '#c7cdd6';
  ctx.fillRect(-27, -80, 34, 5);
  ctx.strokeStyle = '#6d7480';
  ctx.lineWidth = 2;
  ctx.strokeRect(-26, -100, 32, 30);
  ctx.restore();
}

function drawZombieFlag(ctx, zombie, time) {
  const palette = ZOMBIE_PALETTES.flag;
  drawZombieBase(ctx, zombie, time, palette);
  ctx.save();
  ctx.strokeStyle = '#6b4a2a';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-28, -50);
  ctx.lineTo(-40, -104);
  ctx.stroke();
  const wave = Math.sin(num(time, 0) / 260) * 3;
  ctx.fillStyle = palette.headgear;
  ctx.beginPath();
  ctx.moveTo(-40, -104);
  ctx.quadraticCurveTo(-24, -100 + wave, -18, -92 + wave);
  ctx.lineTo(-40, -88);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawZombieFallback(ctx, zombie, time) {
  drawZombieBase(ctx, zombie, time, ZOMBIE_PALETTES.fallback);
}

registerZombieType('basic', drawZombieBasic);
registerZombieType('normal', drawZombieBasic);
registerZombieType('zombie', drawZombieBasic);
registerZombieType('conehead', drawZombieConehead);
registerZombieType('cone_head', drawZombieConehead);
registerZombieType('cone', drawZombieConehead);
registerZombieType('buckethead', drawZombieBuckethead);
registerZombieType('bucket_head', drawZombieBuckethead);
registerZombieType('bucket', drawZombieBuckethead);
registerZombieType('flag', drawZombieFlag);
registerZombieType('flagzombie', drawZombieFlag);
registerZombieType('flag_zombie', drawZombieFlag);

/* ------------------------------------------------------------------ *
 * scene pieces
 * ------------------------------------------------------------------ */

function drawLawn(ctx, layout) {
  ctx.fillStyle = '#5aa235';
  ctx.fillRect(0, 0, layout.width, layout.height);

  // right strip keeps the grass continuous so zombies can walk in off-screen
  if (layout.rightMargin > 0) {
    ctx.fillStyle = '#6bb43c';
    ctx.fillRect(layout.gridX + layout.gridWidth, layout.gridY, layout.rightMargin, layout.gridHeight);
  }

  for (let r = 0; r < layout.rows; r += 1) {
    const y = layout.gridY + r * layout.cellHeight;
    ctx.fillStyle = r % 2 === 0 ? '#7cc24a' : '#6bb43c';
    ctx.fillRect(layout.gridX, y, layout.gridWidth, layout.gridHeight > 0 ? layout.cellHeight : 0);
  }

  ctx.save();
  ctx.globalAlpha = 0.07;
  ctx.fillStyle = '#ffffff';
  for (let c = 0; c < layout.cols; c += 2) {
    ctx.fillRect(layout.gridX + c * layout.cellWidth, layout.gridY, layout.cellWidth, layout.gridHeight);
  }
  ctx.restore();

  ctx.strokeStyle = 'rgba(30, 70, 20, 0.22)';
  ctx.lineWidth = 1;
  for (let r = 1; r < layout.rows; r += 1) {
    const y = layout.gridY + r * layout.cellHeight;
    ctx.beginPath();
    ctx.moveTo(layout.gridX, y);
    ctx.lineTo(layout.gridX + layout.gridWidth, y);
    ctx.stroke();
  }
  for (let c = 1; c < layout.cols; c += 1) {
    const x = layout.gridX + c * layout.cellWidth;
    ctx.beginPath();
    ctx.moveTo(x, layout.gridY);
    ctx.lineTo(x, layout.gridY + layout.gridHeight);
    ctx.stroke();
  }

  // fence at the far right where the waves come from
  if (layout.rightMargin > 6) {
    const fenceX = layout.width - layout.rightMargin + 4;
    ctx.fillStyle = '#8a6b45';
    for (let y = layout.gridY + 4; y < layout.gridY + layout.gridHeight; y += 16) {
      ctx.fillRect(fenceX, y, Math.max(4, layout.rightMargin * 0.25), 10);
    }
  }
}

function drawHouse(ctx, layout) {
  const wallW = layout.gridX;
  const y = layout.gridY;
  const h = layout.gridHeight;
  if (wallW <= 2 || h <= 4) return;

  const wall = ctx.createLinearGradient(0, y, wallW, y);
  wall.addColorStop(0, '#bda07a');
  wall.addColorStop(1, '#8d6f45');
  ctx.fillStyle = wall;
  ctx.fillRect(0, y, wallW, h);

  ctx.strokeStyle = 'rgba(60, 40, 20, 0.22)';
  ctx.lineWidth = 1;
  for (let sy = y + 10; sy < y + h; sy += 12) {
    ctx.beginPath();
    ctx.moveTo(0, sy);
    ctx.lineTo(wallW, sy);
    ctx.stroke();
  }

  // roof wedge
  ctx.fillStyle = '#7a4a2c';
  ctx.beginPath();
  ctx.moveTo(0, y + 20);
  ctx.lineTo(wallW + 6, y - 12);
  ctx.lineTo(wallW + 6, y + 20);
  ctx.closePath();
  ctx.fill();

  // door
  const doorW = Math.max(14, wallW * 0.4);
  const doorH = h * 0.42;
  fillRoundRect(ctx, wallW * 0.3, y + h - doorH, doorW, doorH, 3, '#7b4f2b');
  ctx.fillStyle = '#e0c98a';
  ctx.beginPath();
  ctx.arc(wallW * 0.3 + doorW - 6, y + h - doorH * 0.5, 2.4, 0, Math.PI * 2);
  ctx.fill();

  // windows
  const winW = Math.max(12, wallW * 0.32);
  ctx.fillStyle = '#bfe3f2';
  ctx.fillRect(wallW * 0.18, y + h * 0.18, winW, winW);
  ctx.fillRect(wallW * 0.18, y + h * 0.55, winW, winW);
  ctx.strokeStyle = '#6b4a2a';
  ctx.lineWidth = 2;
  ctx.strokeRect(wallW * 0.18, y + h * 0.18, winW, winW);
  ctx.strokeRect(wallW * 0.18, y + h * 0.55, winW, winW);

  // house boundary: the line a zombie must not cross
  ctx.save();
  ctx.fillStyle = 'rgba(255, 255, 255, 0.30)';
  ctx.fillRect(layout.houseLineX - 2, y, 2, h);
  const shade = ctx.createLinearGradient(layout.houseLineX, 0, layout.houseLineX + 18, 0);
  shade.addColorStop(0, 'rgba(0, 0, 0, 0.22)');
  shade.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = shade;
  ctx.fillRect(layout.houseLineX, y, 18, h);
  ctx.restore();
}

function drawGridHover(ctx, layout, state, view) {
  const cell = view && view.hoveredCell ? view.hoveredCell : null;
  if (!cell) return;
  const row = Math.floor(num(cell.row, -1));
  const col = Math.floor(num(cell.col, -1));
  if (!(row >= 0 && row < layout.rows && col >= 0 && col < layout.cols)) return;
  const x = layout.gridX + col * layout.cellWidth;
  const y = layout.gridY + row * layout.cellHeight;
  ctx.save();
  ctx.fillStyle = view.hoveredCellValid === false ? 'rgba(220,60,60,0.25)' : 'rgba(255,255,255,0.20)';
  ctx.fillRect(x, y, layout.cellWidth, layout.cellHeight);
  ctx.strokeStyle = 'rgba(255,255,255,0.55)';
  ctx.lineWidth = 2;
  ctx.strokeRect(x + 1, y + 1, layout.cellWidth - 2, layout.cellHeight - 2);
  ctx.restore();
}

function drawGhost(ctx, layout, state, view) {
  const type = view && view.selectedPlantType !== undefined && view.selectedPlantType !== null
    ? view.selectedPlantType
    : pick(state, ['selectedPlantType', 'selected', 'carriedPlant'], null);
  const cell = view && view.hoveredCell ? view.hoveredCell : null;
  if (!type || !cell) return;
  const row = Math.floor(num(cell.row, -1));
  const col = Math.floor(num(cell.col, -1));
  if (!(row >= 0 && row < layout.rows && col >= 0 && col < layout.cols)) return;
  if (view && view.hoveredCellValid === false) return;
  const center = gridToPixel(layout, row, col);
  const drawFn = PLANT_DRAWERS.get(String(type)) || drawPlantFallback;
  ctx.save();
  ctx.globalAlpha = 0.55;
  ctx.translate(center.x, center.y);
  ctx.scale(layout.cellWidth / 80, layout.cellHeight / 100);
  drawFn(ctx, { type }, num(view && view.time, 0), layout);
  ctx.restore();
}

function drawHealthBar(ctx, centerX, y, width, height, ratio) {
  if (ratio === null || ratio === undefined || ratio >= 1) return;
  const w = Math.max(12, num(width, 20));
  const h = Math.max(3, num(height, 4));
  const x = centerX - w / 2;
  ctx.save();
  ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
  ctx.fillRect(x, y, w, h);
  const r = clamp(ratio, 0, 1);
  ctx.fillStyle = r > 0.5 ? '#5fd35f' : (r > 0.25 ? '#e8c243' : '#e05353');
  ctx.fillRect(x + 1, y + 1, Math.max(0, (w - 2) * r), Math.max(1, h - 2));
  ctx.restore();
}

function drawPlants(ctx, layout, state, time) {
  const plants = arr(pick(state, ['plants'], null));
  for (let i = 0; i < plants.length; i += 1) {
    const plant = plants[i] && typeof plants[i] === 'object' ? plants[i] : {};
    const row = clamp(Math.floor(num(pick(plant, ['row', 'lane'], 0), 0)), 0, layout.rows - 1);
    const col = clamp(Math.floor(num(pick(plant, ['col', 'column'], 0), 0)), 0, layout.cols - 1);
    const center = gridToPixel(layout, row, col);
    const type = String(pick(plant, ['type', 'kind', 'id', 'plantType'], 'plant'));
    const drawFn = PLANT_DRAWERS.get(type) || drawPlantFallback;
    ctx.save();
    ctx.translate(center.x, center.y);
    ctx.scale(layout.cellWidth / 80, layout.cellHeight / 100);
    drawFn(ctx, plant, time, layout);
    ctx.restore();
    drawHealthBar(
      ctx,
      center.x,
      center.y - layout.cellHeight * 0.44,
      layout.cellWidth * 0.62,
      Math.max(3, layout.cellHeight * 0.045),
      healthRatio(plant),
    );
  }
}

function drawProjectiles(ctx, layout, state, time) {
  const list = arr(pick(state, ['projectiles', 'bullets', 'peas', 'shots'], null));
  const radius = Math.max(4, layout.cellWidth * 0.11);
  for (let i = 0; i < list.length; i += 1) {
    const shot = list[i] && typeof list[i] === 'object' ? list[i] : {};
    const point = entityPixel(layout, shot);
    const type = String(pick(shot, ['type', 'kind', 'id'], 'pea'));
    const color = PROJECTILE_COLORS[type] || '#8bd44a';
    ctx.save();
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(point.x, point.y, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(20, 60, 10, 0.35)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.beginPath();
    ctx.arc(point.x - radius * 0.3, point.y - radius * 0.35, radius * 0.32, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

function drawZombies(ctx, layout, state, time) {
  const zombies = arr(pick(state, ['zombies'], null));
  for (let i = 0; i < zombies.length; i += 1) {
    const zombie = zombies[i] && typeof zombies[i] === 'object' ? zombies[i] : {};
    const row = clamp(Math.floor(num(pick(zombie, ['row', 'lane'], 0), 0)), 0, layout.rows - 1);
    const point = entityPixel(layout, zombie, row);
    const type = String(pick(zombie, ['type', 'kind', 'id', 'zombieType'], 'basic'));
    const drawFn = ZOMBIE_DRAWERS.get(type) || drawZombieFallback;
    const scale = Math.max(0.2, layout.cellWidth / 80);
    const feetY = point.y + layout.cellHeight * 0.32;
    ctx.save();
    ctx.translate(point.x, feetY);
    ctx.scale(scale, scale * 0.95);
    drawFn(ctx, zombie, time);
    ctx.restore();
    drawHealthBar(
      ctx,
      point.x,
      feetY - 104 * scale * 0.95,
      Math.max(18, layout.cellWidth * 0.5),
      Math.max(3, layout.cellHeight * 0.04),
      healthRatio(zombie),
    );
  }
}

function drawSunToken(ctx, layout, sun, time) {
  const point = entityPixel(layout, sun);
  const radius = Math.max(8, layout.cellWidth * 0.22);
  const pulse = 1 + Math.sin(num(time, 0) / 300 + num(pick(sun, ['phase'], 0), 0)) * 0.04;
  ctx.save();
  ctx.translate(point.x, point.y);
  ctx.scale(pulse, pulse);
  const glow = ctx.createRadialGradient(0, 0, radius * 0.2, 0, 0, radius * 1.7);
  glow.addColorStop(0, 'rgba(255, 246, 180, 0.95)');
  glow.addColorStop(0.45, 'rgba(255, 214, 60, 0.55)');
  glow.addColorStop(1, 'rgba(255, 200, 40, 0)');
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(0, 0, radius * 1.7, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#ffd83b';
  const spin = num(time, 0) / 1400;
  for (let i = 0; i < 10; i += 1) {
    ctx.save();
    ctx.rotate(spin + (i / 10) * Math.PI * 2);
    ctx.beginPath();
    ctx.moveTo(0, -radius * 0.55);
    ctx.lineTo(-radius * 0.22, -radius * 1.05);
    ctx.lineTo(radius * 0.22, -radius * 1.05);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  ctx.beginPath();
  ctx.arc(0, 0, radius * 0.66, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#fff3b0';
  ctx.beginPath();
  ctx.arc(-radius * 0.16, -radius * 0.16, radius * 0.28, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawSuns(ctx, layout, state, time) {
  const suns = arr(pick(state, ['suns', 'sunTokens'], null));
  for (let i = 0; i < suns.length; i += 1) {
    drawSunToken(ctx, layout, suns[i] && typeof suns[i] === 'object' ? suns[i] : {}, time);
  }
}

function drawSunIcon(ctx, cx, cy, r, time) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.fillStyle = '#ffd83b';
  const spin = num(time, 0) / 1800;
  for (let i = 0; i < 8; i += 1) {
    ctx.save();
    ctx.rotate(spin + (i / 8) * Math.PI * 2);
    ctx.beginPath();
    ctx.moveTo(0, -r * 0.8);
    ctx.lineTo(-r * 0.28, -r * 1.5);
    ctx.lineTo(r * 0.28, -r * 1.5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#fff3b0';
  ctx.beginPath();
  ctx.arc(-r * 0.25, -r * 0.25, r * 0.4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawSunCounter(ctx, box, sun, time) {
  fillRoundRect(ctx, box.x, box.y, box.width, box.height, 8, '#f7ecc2');
  strokeRoundRect(ctx, box.x, box.y, box.width, box.height, 8, '#8a6a2c', 2);
  const r = Math.min(box.width * 0.22, box.height * 0.26);
  drawSunIcon(ctx, box.x + r + 8, box.y + box.height / 2, r, num(time, 0));
  ctx.save();
  ctx.font = 'bold ' + Math.max(14, Math.round(box.height * 0.34)) + 'px system-ui, sans-serif';
  ctx.textAlign = 'right';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#4a3410';
  ctx.fillText(String(Math.floor(num(sun, 0))), box.x + box.width - 10, box.y + box.height / 2 + 1);
  ctx.restore();
}

function drawSeedPacket(ctx, rect, packet, view, time) {
  const x = rect.x;
  const y = rect.y;
  const w = rect.width;
  const h = rect.height;
  const r = 6;

  ctx.save();
  ctx.beginPath();
  roundRectPath(ctx, x, y, w, h, r);
  ctx.fillStyle = packet.disabled ? '#cbbc92' : '#efdfae';
  ctx.fill();
  ctx.strokeStyle = '#7b5c25';
  ctx.lineWidth = 2;
  ctx.stroke();

  const drawFn = PLANT_DRAWERS.get(packet.type) || drawPlantFallback;
  ctx.save();
  ctx.beginPath();
  roundRectPath(ctx, x + 3, y + 3, Math.max(1, w - 6), Math.max(1, h - 6), r - 2);
  ctx.clip();
  ctx.translate(x + w / 2, y + h * 0.44);
  const s = Math.min(w / 90, h / 130);
  ctx.scale(s, s);
  drawFn(ctx, { type: packet.type, hp: 1, maxHp: 1 }, num(time, 0), null);
  ctx.restore();

  if (packet.cost > 0) {
    ctx.font = 'bold ' + Math.max(10, Math.round(h * 0.17)) + 'px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = '#3a2b12';
    ctx.fillText(String(packet.cost), x + w / 2, y + h - 6);
  }

  if (packet.cooldownRatio > 0) {
    ctx.save();
    ctx.beginPath();
    roundRectPath(ctx, x, y, w, h, r);
    ctx.clip();
    ctx.fillStyle = 'rgba(10, 10, 10, 0.55)';
    ctx.fillRect(x, y, w, h * clamp(packet.cooldownRatio, 0, 1));
    ctx.restore();
  } else if (packet.disabled) {
    ctx.save();
    ctx.beginPath();
    roundRectPath(ctx, x, y, w, h, r);
    ctx.clip();
    ctx.fillStyle = 'rgba(60, 60, 60, 0.42)';
    ctx.fillRect(x, y, w, h);
    ctx.restore();
  }

  if (packet.selected) {
    ctx.beginPath();
    roundRectPath(ctx, x, y, w, h, r);
    ctx.fillStyle = 'rgba(255, 240, 140, 0.18)';
    ctx.fill();
    strokeRoundRect(ctx, x - 2, y - 2, w + 4, h + 4, r + 2, '#ffe14d', 3);
  }

  if (view && view.showHotkeys) {
    ctx.font = 'bold ' + Math.max(9, Math.round(h * 0.13)) + 'px system-ui, sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';
    ctx.fillStyle = 'rgba(40, 30, 10, 0.75)';
    ctx.fillText(String(packet.index + 1), x + 4, y + 3);
  }
  ctx.restore();
}

function drawSeedBank(ctx, layout, state, view, time) {
  const sun = sunOf(state);
  const packets = normalizeSeedPackets(state, sun);
  const geo = seedBankGeometry(layout, packets.length);

  const panel = ctx.createLinearGradient(0, 0, 0, Math.max(1, layout.topBarHeight));
  panel.addColorStop(0, '#8a6636');
  panel.addColorStop(1, '#5c421f');
  ctx.fillStyle = panel;
  ctx.fillRect(0, 0, layout.width, layout.topBarHeight);
  ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
  ctx.fillRect(0, Math.max(0, layout.topBarHeight - 3), layout.width, 3);

  drawSunCounter(ctx, geo.sunBox, sun, time);
  for (let i = 0; i < packets.length; i += 1) {
    drawSeedPacket(ctx, geo.cards[i], packets[i], view, time);
  }
}

function resolveWave(state) {
  const s = state && typeof state === 'object' ? state : {};
  const raw = pick(s, ['wave'], null);
  let index = num(pick(s, ['waveIndex', 'currentWave'], null), NaN);
  let total = num(pick(s, ['waveTotal', 'totalWaves'], null), NaN);
  let progress = num(pick(s, ['waveProgress'], null), NaN);

  if (raw && typeof raw === 'object') {
    index = num(pick(raw, ['index', 'current', 'number'], null), index);
    total = num(pick(raw, ['total', 'count', 'max'], null), total);
    progress = num(pick(raw, ['progress', 'fraction'], null), progress);
  } else if (Number.isFinite(num(raw, NaN))) {
    index = num(raw, index);
  }

  const hasIndex = Number.isFinite(index);
  const hasTotal = Number.isFinite(total) && total > 0;
  if (!Number.isFinite(progress)) {
    progress = hasIndex && hasTotal ? clamp(index / total, 0, 1) : NaN;
  }
  return {
    index: hasIndex ? index : (hasTotal ? 0 : 0),
    total: hasTotal ? total : 0,
    progress: Number.isFinite(progress) ? clamp(progress, 0, 1) : 0,
    hasData: hasIndex || hasTotal || Number.isFinite(progress) || pick(s, ['wave'], null) !== null,
  };
}

function resolveLabels(view) {
  const v = view && typeof view === 'object' ? view : {};
  const provided = v.labels && typeof v.labels === 'object' ? v.labels : {};
  return Object.assign({}, DEFAULT_LABELS, provided);
}

function drawHud(ctx, layout, state, view) {
  const stripH = layout.bottomBarHeight;
  if (stripH <= 4) return;
  const y = layout.height - stripH;
  ctx.fillStyle = '#3f2f19';
  ctx.fillRect(0, y, layout.width, stripH);

  const wave = resolveWave(state);
  const labels = resolveLabels(view);
  const midY = y + stripH / 2;

  ctx.save();
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'left';
  if (wave.hasData) {
    ctx.font = 'bold 14px system-ui, sans-serif';
    ctx.fillStyle = '#f7e7b0';
    const label = String(labels.wave) + ' ' + String(Math.max(1, Math.round(wave.index))) + ' / ' + String(Math.max(1, Math.round(wave.total) || 1));
    ctx.fillText(label, 14, midY);
    const barX = 14 + ctx.measureText(label).width + 16;
    const barW = Math.max(50, layout.width - barX - 14);
    const barH = Math.max(8, Math.min(14, stripH - 16));
    const barY = midY - barH / 2;
    fillRoundRect(ctx, barX, barY, barW, barH, barH / 2, 'rgba(0, 0, 0, 0.4)');
    fillRoundRect(ctx, barX, barY, Math.max(1, barW * wave.progress), barH, barH / 2, '#f2c14e');
  } else if (labels.hint) {
    ctx.font = '12px system-ui, sans-serif';
    ctx.fillStyle = '#c9b184';
    ctx.fillText(String(labels.hint), 14, midY);
  }
  ctx.restore();
}

function resolveStatus(state) {
  const s = state && typeof state === 'object' ? state : {};
  const raw = pick(s, ['status', 'gameStatus', 'phase'], null);
  if (typeof raw === 'string') {
    const v = raw.toLowerCase();
    if (v === 'won' || v === 'win' || v === 'victory' || v === 'complete' || v === 'completed') return 'won';
    if (v === 'lost' || v === 'lose' || v === 'defeat' || v === 'gameover' || v === 'game_over') return 'lost';
    if (v === 'playing' || v === 'running' || v === 'active' || v === 'ready' || v === 'paused' || v === 'idle') return 'playing';
  }
  if (pick(s, ['won', 'isWin', 'victory', 'clickedWin'], false) === true) return 'won';
  if (pick(s, ['lost', 'isLost', 'gameOver', 'defeat'], false) === true) return 'lost';
  return 'playing';
}

function drawStatusOverlay(ctx, layout, state, view) {
  const status = resolveStatus(state);
  if (status === 'playing') return;
  const labels = resolveLabels(view);

  ctx.save();
  ctx.fillStyle = status === 'won' ? 'rgba(10, 30, 10, 0.55)' : 'rgba(35, 5, 5, 0.62)';
  ctx.fillRect(0, 0, layout.width, layout.height);

  const title = status === 'won' ? String(labels.won) : String(labels.lost);
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = 'bold ' + Math.max(20, Math.round(layout.height * 0.085)) + 'px system-ui, sans-serif';
  ctx.lineWidth = 6;
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.6)';
  ctx.strokeText(title, layout.width / 2, layout.height / 2);
  ctx.fillStyle = status === 'won' ? '#ffe36e' : '#ff8a7a';
  ctx.fillText(title, layout.width / 2, layout.height / 2);

  if (labels.restartHint) {
    ctx.font = '16px system-ui, sans-serif';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    ctx.fillText(String(labels.restartHint), layout.width / 2, layout.height / 2 + layout.height * 0.09);
  }
  ctx.restore();
}

/* ------------------------------------------------------------------ *
 * scene + renderer
 * ------------------------------------------------------------------ */

/** Draw a complete frame. Pure with respect to `state`; safe to unit test. */
export function drawScene(ctx, layout, state, view) {
  if (!ctx || typeof ctx.fillRect !== 'function') throw new TypeError('drawScene requires a Canvas 2D context');
  const s = state && typeof state === 'object' ? state : {};
  const v = Object.assign({ time: nowMs() }, view || {});
  const time = num(v.time, 0);

  ctx.save();
  ctx.clearRect(0, 0, layout.width, layout.height);
  drawLawn(ctx, layout);
  drawHouse(ctx, layout);
  drawGridHover(ctx, layout, s, v);
  drawGhost(ctx, layout, s, v);
  drawPlants(ctx, layout, s, time);
  drawProjectiles(ctx, layout, s, time);
  drawZombies(ctx, layout, s, time);
  drawSuns(ctx, layout, s, time);
  drawSeedBank(ctx, layout, s, v, time);
  drawHud(ctx, layout, s, v);
  drawStatusOverlay(ctx, layout, s, v);
  ctx.restore();
  return { width: layout.width, height: layout.height, time };
}

export function createRenderer(canvas, options) {
  if (!canvas || typeof canvas.getContext !== 'function') {
    throw new TypeError('createRenderer(canvas) requires a canvas-like object');
  }
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new TypeError('canvas.getContext("2d") returned null');

  const opts = Object.assign({}, options || {});
  const internal = {
    options: opts,
    layout: createLayout(Object.assign(
      {
        width: num(canvas.width, DEFAULT_LAYOUT_OPTIONS.width),
        height: num(canvas.height, DEFAULT_LAYOUT_OPTIONS.height),
      },
      opts,
    )),
    frameCount: 0,
    lastFrame: null,
  };

  const renderer = {
    canvas,
    ctx,
    version: RENDERER_VERSION,
    get layout() {
      return internal.layout;
    },
    get frameCount() {
      return internal.frameCount;
    },
    get lastFrame() {
      return internal.lastFrame;
    },
    setLayout(overrides) {
      internal.layout = createLayout(Object.assign({}, internal.options, overrides || {}));
      return internal.layout;
    },
    resize(width, height, resizeOptions) {
      const w = Math.max(320, Math.floor(num(width, internal.layout.width)));
      const h = Math.max(260, Math.floor(num(height, internal.layout.height)));
      let dpr = num(resizeOptions && resizeOptions.devicePixelRatio, NaN);
      if (!Number.isFinite(dpr)) {
        dpr = typeof window !== 'undefined' && window && Number.isFinite(window.devicePixelRatio)
          ? window.devicePixelRatio
          : 1;
      }
      dpr = Math.max(1, dpr);
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      if (canvas.style) {
        canvas.style.width = w + 'px';
        canvas.style.height = h + 'px';
      }
      internal.layout = createLayout(Object.assign({}, internal.options, { width: w, height: h }));
      if (typeof ctx.setTransform === 'function') ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      return internal.layout;
    },
    seedBank(state) {
      const sun = sunOf(state);
      return seedBankGeometry(internal.layout, normalizeSeedPackets(state, sun).length);
    },
    packets(state) {
      return normalizeSeedPackets(state, sunOf(state));
    },
    hitTestSeedPacket(x, y, state) {
      const packets = normalizeSeedPackets(state, sunOf(state));
      const geo = seedBankGeometry(internal.layout, packets.length);
      for (let i = 0; i < geo.cards.length; i += 1) {
        const rect = geo.cards[i];
        if (x >= rect.x && x <= rect.x + rect.width && y >= rect.y && y <= rect.y + rect.height) {
          return { index: i, rect, packet: packets[i], type: packets[i].type };
        }
      }
      return null;
    },
    hitTestGrid(x, y) {
      return pixelToGrid(internal.layout, x, y);
    },
    render(state, view) {
      const v = view && typeof view === 'object' ? view : {};
      const time = Number.isFinite(v.time) ? v.time : nowMs();
      drawScene(ctx, internal.layout, state, Object.assign({}, v, { time }));
      internal.frameCount += 1;
      internal.lastFrame = { time, frame: internal.frameCount, width: internal.layout.width, height: internal.layout.height };
      return internal.lastFrame;
    },
    draw(state, view) {
      return renderer.render(state, view);
    },
  };

  return renderer;
}

export default {
  RENDERER_VERSION,
  DEFAULT_GRID,
  DEFAULT_LAYOUT_OPTIONS,
  DEFAULT_LABELS,
  PROJECTILE_COLORS,
  RENDERER_STATE_CONTRACT,
  createLayout,
  gridToPixel,
  pixelToGrid,
  entityPixel,
  seedBankGeometry,
  sunOf,
  normalizeSeedPackets,
  registerPlantType,
  registerZombieType,
  getPlantTypes,
  getZombieTypes,
  PLANT_DRAWERS,
  ZOMBIE_DRAWERS,
  drawScene,
  createRenderer,
};
